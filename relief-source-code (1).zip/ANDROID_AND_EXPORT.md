# RELIEF — Android Build & Source Export Guide

## 1. Export Source Code as ZIP
From your terminal in the project root (excluding generated build artifacts and dependencies):

```bash
zip -r relief-wisdom-source.zip . -x "node_modules/*" "dist/*" "android/app/build/*" ".git/*"
```

## 2. Environment & Server Setup
RELIEF uses a secure Express backend (`server.ts`) that serves:
- Complete verified Quran (`server/data/quran.json`: 114 Surahs, 6,236 Ayahs)
- Complete verified Bhagavad Gita (`server/data/gita.json`: 18 Chapters, 700 Shlokas)
- Server-side Gemini AI synthesis (`/api/ask-relief`) protected by `process.env.GEMINI_API_KEY`

Copy `.env.example` to `.env` and configure `GEMINI_API_KEY` on your server host (never in client code).

## 3. Generate the Capacitor Android Project
First build the web bundle (`dist/`), then add and sync the Android platform:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
```

To point the Android app to your hosted RELIEF backend for `/api/*` calls, configure `server.url` in `capacitor.config.ts` (for production HTTPS deployment) or configure a reverse proxy / `VITE_API_BASE_URL` before running `npm run cap:sync`.

## 4. Build a Test APK (Debug)
Open `android/` in Android Studio or build via Gradle:

```bash
cd android
./gradlew assembleDebug
```
Output APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## 5. Build a Signed Android App Bundle (AAB) for Google Play
1. Generate a release keystore (keep it backed up securely):
```bash
keytool -genkey -v -keystore relief-release.keystore -alias relief -keyalg RSA -keysize 2048 -validity 10000
```
2. Configure `signingConfigs.release` in `android/app/build.gradle` (using environment variables or `keystore.properties`, never committing passwords to git).
3. Build the signed AAB:
```bash
cd android
./gradlew bundleRelease
```
Output AAB: `android/app/build/outputs/bundle/release/app-release.aab`
