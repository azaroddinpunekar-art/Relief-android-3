# RELIEF — Two Scriptures. Shared Wisdom. One Humanity.

RELIEF is a secular, inclusive, scripture-based wisdom and reflection platform exploring **The Holy Quran** and **The Bhagavad Gita** side by side in English, Hindi, Arabic, and Sanskrit.

## Key Features
- **Complete Scripture Library**:
  - **The Holy Quran**: All 114 Surahs (6,236 Ayahs) in Arabic (Uthmani), English, and Hindi.
  - **The Bhagavad Gita**: All 18 Chapters (700 Shlokas) in Sanskrit (Devanagari), IAST transliteration, English, and Hindi.
  - Cross-scripture search, chapter/verse navigation, bookmarking with personal notes, and sharing.
- **One Humanity**: 15 universal human values (*Compassion, Truthfulness, Forgiveness, Justice, Kindness, Self-Control, Humility, Duty & Responsibility, Greed & Attachment, Anger Management, Peace & Patience, Respect for Humanity, Helping Others, Integrity, Purpose of Life*) examined independently and comparatively without forcing artificial sameness.
- **Ask RELIEF**: Multi-turn conversational AI wisdom reflection powered by Google Gemini (`@google/genai`) on the Express backend, strictly grounded in retrieved verified verses from the local archive.
- **Situation Explorer**: 11 everyday life categories plus open custom situation entry.
- **Bilingual Interface**: Full English and Hindi (`हिन्दी`) UI support.
- **Android Ready**: Configured with Capacitor (`capacitor.config.ts` and `android/`) plus a GitHub Actions workflow to build a test APK automatically.

---

## Quick Start (Local Development)

### Prerequisites
- Node.js 20+
- A Gemini API key from Google AI Studio

### Setup
```bash
npm install
cp .env.example .env
# Add your GEMINI_API_KEY in .env
npm run dev
```
The server starts on `http://localhost:3000`.

### Production Build & Start
```bash
npm run build
npm start
```

---

## Push to GitHub

1. Download `relief-source-code.zip` from **Profile → Download Source Code (ZIP)** inside the app and extract it.
2. Create a new repository on GitHub (without initializing a README).
3. Run inside the extracted folder:
```bash
git init
git add .
git commit -m "Initial commit: RELIEF Wisdom Platform"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
git push -u origin main
```

---

## Build Android APK & Signed AAB

### Option A: Automatic Test APK via GitHub Actions
Once pushed to GitHub, open the **Actions** tab and run **Build Android Test APK** (or push to `main`). Download the compiled `app-debug.apk` from the workflow artifacts.

### Option B: Local Android Studio / Gradle
Point `server.url` in `capacitor.config.ts` to your hosted RELIEF backend URL if calling `/api/*` remotely, then run:
```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug     # Outputs android/app/build/outputs/apk/debug/app-debug.apk
./gradlew bundleRelease     # Outputs signed android/app/build/outputs/bundle/release/app-release.aab
```

---

## Scripture & Translation Attributions
- **Quran Arabic**: Tanzil Project (Quran Uthmani) via AlQuran Cloud
- **Quran English**: Saheeh International via AlQuran Cloud
- **Quran Hindi**: Suhel Farooq Khan & Saifur Rahman Nadwi via AlQuran Cloud
- **Bhagavad Gita Sanskrit & IAST**: Vedic Scriptures Open Archive
- **Bhagavad Gita English**: Swami Sivananda via Vedic Scriptures Open Archive
- **Bhagavad Gita Hindi**: Swami Tejomayananda via Vedic Scriptures Open Archive

## Educational & Neutrality Notice
RELIEF is an educational and reflective platform, not a religious authority. AI-generated reflections are never substitutes for qualified medical, mental-health, legal, financial, or emergency care.
