import { hydrateGitaVerse, hydrateQuranVerse, HydratedVerse } from './scriptureService.ts';

export interface BilingualText {
  en: string;
  hi: string;
}

export interface OneHumanityTopicRaw {
  id: string;
  title: BilingualText;
  subtitle: BilingualText;
  quranRef: { surah: number; ayah: number };
  gitaRef: { chapter: number; verse: number };
  quranExplanation: BilingualText;
  gitaExplanation: BilingualText;
  sharedPrinciple: BilingualText;
  differences: BilingualText;
  practicalApplication: BilingualText;
}

export interface SituationCategoryRaw {
  id: string;
  title: BilingualText;
  summary: BilingualText;
  quranRefs: Array<{ surah: number; ayah: number }>;
  gitaRefs: Array<{ chapter: number; verse: number }>;
  reflection: BilingualText;
  practicalSteps: { en: string[]; hi: string[] };
}

const ONE_HUMANITY_TOPICS: OneHumanityTopicRaw[] = [
  {
    id: 'compassion',
    title: { en: 'Compassion', hi: 'करुणा और दया' },
    subtitle: {
      en: 'Meeting suffering with mercy and non-harm',
      hi: 'दूसरों के दुख के प्रति करुणा और अहिंसा का भाव',
    },
    quranRef: { surah: 16, ayah: 90 },
    gitaRef: { chapter: 12, verse: 13 },
    quranExplanation: {
      en: 'In Quran 16:90, justice and "ihsan" (doing good with excellence and compassion) stand alongside caring for relatives and rejecting cruelty. Compassion is framed as an active moral obligation woven into social conduct.',
      hi: 'क़ुरआन 16:90 में न्याय और "इहसान" (उत्कृष्ट करुणा व भलाई) को पारिवारिक देखभाल और अन्याय के त्याग के साथ रखा गया है। यहाँ करुणा एक सक्रिय सामाजिक और नैतिक दायित्व है।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 12:13 describes the balanced, wise person as one who bears ill-will toward no creature, remains friendly and compassionate to all, and lets go of possessiveness and ego.',
      hi: 'भगवद्गीता 12:13 में आदर्श साधक को ऐसा बताया गया है जो किसी भी प्राणी से द्वेष नहीं रखता, सबके प्रति मित्रवत और करुणामय रहता है, तथा अहंकार और ममत्व से मुक्त होता है।',
    },
    sharedPrinciple: {
      en: 'Both texts treat compassion not as passive pity, but as disciplined goodwill—refusing to harm others while actively caring for living beings.',
      hi: 'दोनों ग्रंथ करुणा को केवल भावनात्मक सहानुभूति नहीं, बल्कि अनुशासित सद्भावना मानते हैं—जहाँ किसी को कष्ट न पहुँचाना और भलाई करना मुख्य है।',
    },
    differences: {
      en: 'The Quran grounds compassion in social justice, duty toward kin, and accountability before God. The Gita links compassion to inner equanimity and seeing all beings without ego-driven attachment.',
      hi: 'क़ुरआन करुणा को सामाजिक न्याय, संबंधियों के प्रति कर्तव्य और ईश्वर के प्रति जवाबदेही से जोड़ता है, जबकि गीता इसे आंतरिक समभाव और अहंकार-रहित दृष्टि से जोड़ती है।',
    },
    practicalApplication: {
      en: 'Before responding to someone who frustrates you today, pause to ask what unseen pressure they may carry, and choose one concrete act of fairness or gentleness.',
      hi: 'आज किसी की बात से चिढ़ने से पहले रुककर सोचें कि वह किस दबाव में हो सकता है, और प्रतिक्रिया के बजाय एक शांत व न्यायपूर्ण कदम चुनें।',
    },
  },
  {
    id: 'truthfulness',
    title: { en: 'Truthfulness', hi: 'सत्यनिष्ठा' },
    subtitle: {
      en: 'Refusing deceit in speech and conscience',
      hi: 'वाणी और आचरण में सत्य का पालन',
    },
    quranRef: { surah: 2, ayah: 42 },
    gitaRef: { chapter: 17, verse: 15 },
    quranExplanation: {
      en: 'Quran 2:42 warns directly against blending truth with falsehood or deliberately concealing what one knows to be true. Integrity of testimony is vital for trust in any community.',
      hi: 'क़ुरआन 2:42 स्पष्ट चेतावनी देता है कि सत्य को असत्य के साथ न मिलाया जाए और न ही जानते हुए सच को छिपाया जाए। समाज के विश्वास के लिए सत्यनिष्ठा अनिवार्य है।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 17:15 defines "austerity of speech" as words that do not agitate others, while remaining truthful, pleasant, and genuinely beneficial.',
      hi: 'भगवद्गीता 17:15 "वाणी के तप" को परिभाषित करते हुए कहती है कि वाणी ऐसी हो जो किसी को उत्तेजित न करे, सत्य हो, प्रिय हो और हितकारी हो।',
    },
    sharedPrinciple: {
      en: 'Both scriptures affirm that truth must never be twisted for convenience, and that honest speech requires moral discipline.',
      hi: 'दोनों ग्रंथ स्वीकार करते हैं कि स्वार्थ के लिए सत्य को तोड़ा-मरोड़ा नहीं जाना चाहिए और सत्य बोलने के लिए आत्म-संयम आवश्यक है।',
    },
    differences: {
      en: 'Quran 2:42 emphasizes civic and epistemic honesty—not hiding or distorting truth. Gita 17:15 pairs truthfulness with psychological gentleness, asking that truth be spoken without needless harshness.',
      hi: 'क़ुरआन 2:42 सच को न छिपाने और न्यायिक ईमानदारी पर बल देता है, जबकि गीता 17:15 सत्य के साथ-साथ वाणी की कोमलता और हितकारिता को भी अनिवार्य मानती है।',
    },
    practicalApplication: {
      en: 'In difficult conversations, state facts honestly without exaggeration, and frame hard truths calmly so they heal or clarify rather than wound.',
      hi: 'कठिन बातचीत में बिना बढ़ा-चढ़ाकर तथ्य सामने रखें, और कड़वे सच को भी शांत व स्पष्ट शब्दों में कहें ताकि समाधान निकले, आघात नहीं।',
    },
  },
  {
    id: 'forgiveness',
    title: { en: 'Forgiveness', hi: 'क्षमा' },
    subtitle: {
      en: 'Choosing reconciliation over endless retaliation',
      hi: 'प्रतिशोध के बजाय मेल-मिलाप और क्षमा का मार्ग',
    },
    quranRef: { surah: 42, ayah: 40 },
    gitaRef: { chapter: 16, verse: 3 },
    quranExplanation: {
      en: 'Quran 42:40 acknowledges the legal principle of proportionate response to harm, yet immediately elevates pardoning and reconciliation as the higher moral path rewarded by God.',
      hi: 'क़ुरआन 42:40 बुराई के बराबर प्रतिकार की सीमा स्वीकार करते हुए भी तुरंत यह स्पष्ट करता है कि जो व्यक्ति क्षमा कर दे और सुधार करे, उसका प्रतिफल श्रेष्ठ है।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 16:3 lists forgiveness (kshama), fortitude, purity, and absence of hatred among the noble qualities that elevate human character.',
      hi: 'भगवद्गीता 16:3 में क्षमा, धैर्य, पवित्रता और द्वेष के अभाव को दैवीय अर्थात उच्च मानवीय गुणों में गिना गया है।',
    },
    sharedPrinciple: {
      en: 'Both traditions view forgiveness not as weakness, but as inner strength that breaks cycles of resentment and hostility.',
      hi: 'दोनों परंपराएँ क्षमा को कमज़ोरी नहीं, बल्कि एक ऐसी आंतरिक शक्ति मानती हैं जो शत्रुता और कटुता के चक्र को तोड़ती है।',
    },
    differences: {
      en: 'The Quran situates forgiveness alongside social justice and active reconciliation ("islah"), whereas the Gita treats forgiveness as a personal virtue rooted in inner steadiness and freedom from malice.',
      hi: 'क़ुरआन क्षमा को सामाजिक न्याय और सुलह के संदर्भ में रखता है, जबकि गीता इसे व्यक्तिगत चरित्र और द्वेष-मुक्ति के एक आंतरिक गुण के रूप में देखती है।',
    },
    practicalApplication: {
      en: 'Where a relationship is safe, release the urge to punish or replay past slights. Forgiveness can mean setting clear boundaries while letting go of bitterness.',
      hi: 'जहाँ संबंध सुरक्षित हों, वहाँ मन में पुरानी चोटों को दोहराना छोड़ें। क्षमा का अर्थ स्पष्ट सीमाएँ रखते हुए भी भीतर से कड़वाहट मुक्त करना है।',
    },
  },
  {
    id: 'justice',
    title: { en: 'Justice', hi: 'न्याय' },
    subtitle: {
      en: 'Standing for fairness even against self-interest',
      hi: 'स्वार्थ और पक्षपात से ऊपर उठकर निष्पक्ष न्याय',
    },
    quranRef: { surah: 4, ayah: 135 },
    gitaRef: { chapter: 4, verse: 7 },
    quranExplanation: {
      en: 'Quran 4:135 commands believers to stand firmly for justice as truthful witnesses—even if doing so goes against themselves, their parents, or close relatives, regardless of wealth or poverty.',
      hi: 'क़ुरआन 4:135 स्पष्ट आदेश देता है कि न्याय के लिए मजबूती से खड़े रहें—चाहे गवाही स्वयं के, माता-पिता या रिश्तेदारों के विरुद्ध ही क्यों न जाए, और अमीर-गरीब का भेद न करें।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 4:7 speaks of the cosmic restoration of dharma (moral order and righteousness) whenever unrighteousness threatens to overwhelm society.',
      hi: 'भगवद्गीता 4:7 धर्म (नैतिक व्यवस्था और न्याय) की रक्षा के महत्व को दर्शाती है, जहाँ अधर्म बढ़ने पर नैतिक संतुलन की पुनर्स्थापना होती है।',
    },
    sharedPrinciple: {
      en: 'Both scriptures affirm that moral order and fairness outweigh personal convenience, tribal loyalty, or material status.',
      hi: 'दोनों ग्रंथ इस बात पर सहमत हैं कि नैतिक व्यवस्था और न्याय, व्यक्तिगत स्वार्थ, पक्षपात या धन-पद से कहीं ऊपर हैं।',
    },
    differences: {
      en: 'Quran 4:135 offers a concrete civic directive for individual impartiality in courts, families, and society. Gita 4:7 frames righteousness on a cosmic, historical scale through divine preservation of dharma.',
      hi: 'क़ुरआन 4:135 व्यक्तिगत और कानूनी निष्पक्षता का सीधा व्यवहारिक नियम देता है, जबकि गीता 4:7 धर्म की रक्षा को ब्रह्मांडीय और ऐतिहासिक संतुलन के रूप में प्रस्तुत करती है।',
    },
    practicalApplication: {
      en: 'Notice where bias toward friends, status, or convenience colors your judgment at work or home, and commit to one fair decision based purely on facts.',
      hi: 'ध्यान दें कि कहाँ मित्रता, पद या सुविधा के कारण आपका निर्णय प्रभावित होता है, और केवल तथ्यों के आधार पर निष्पक्ष निर्णय लें।',
    },
  },
  {
    id: 'kindness',
    title: { en: 'Kindness', hi: 'सज्जनता और उदारता' },
    subtitle: {
      en: 'Dignity in speech outweighs material gifts',
      hi: 'मधुर वाणी और सम्मान का महत्व भौतिक दान से अधिक',
    },
    quranRef: { surah: 2, ayah: 263 },
    gitaRef: { chapter: 17, verse: 20 },
    quranExplanation: {
      en: 'Quran 2:263 teaches that a kind word and forgiving spirit are worth more than charity followed by hurt, insult, or condescension.',
      hi: 'क़ुरआन 2:263 बताता है कि मीठी बात और क्षमा उस दान से कहीं बेहतर है जिसके बाद किसी को ताना या मानसिक पीड़ा दी जाए।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 17:20 defines pure (sattvic) giving as generosity offered out of duty, at the right time and place, to a worthy recipient without expecting anything in return.',
      hi: 'भगवद्गीता 17:20 सात्विक दान को ऐसा मानती है जो बिना किसी प्रतिफल की अपेक्षा के, उचित समय व स्थान पर कर्तव्य मानकर दिया जाए।',
    },
    sharedPrinciple: {
      en: 'Both texts emphasize that how we give and speak matters deeply—generosity loses its ethical beauty when paired with ego or humiliation.',
      hi: 'दोनों ग्रंथ सिखाते हैं कि देने और बोलने का तरीका अत्यंत महत्वपूर्ण है; अहंकार या अपमान से जुड़ा दान अपना नैतिक मूल्य खो देता है।',
    },
    differences: {
      en: 'The Quranic verse highlights emotional care in everyday human interaction ("kind speech"). The Gita categorizes generosity into psychological qualities (sattvic vs. ego-driven giving).',
      hi: 'क़ुरआन की आयत दैनिक व्यवहार में कोमल वाणी और संवेदनशीलता पर केंद्रित है, जबकि गीता दान की मानसिक प्रेरणाओं (सात्विक बनाम स्वार्थी भाव) का विश्लेषण करती है।',
    },
    practicalApplication: {
      en: 'When helping someone, protect their dignity—offer assistance quietly without expecting praise or reminding them of your favor.',
      hi: 'किसी की मदद करते समय उसके आत्म-सम्मान की रक्षा करें—बिना प्रशंसा की अपेक्षा या एहसान जताए सहयोग करें।',
    },
  },
  {
    id: 'self-control',
    title: { en: 'Self-Control', hi: 'आत्म-संयम' },
    subtitle: {
      en: 'Mastering the restless mind and impulses',
      hi: 'चंचल मन और आवेगों पर संयम',
    },
    quranRef: { surah: 7, ayah: 31 },
    gitaRef: { chapter: 6, verse: 35 },
    quranExplanation: {
      en: 'Quran 7:31 encourages enjoying lawful sustenance and beauty while firmly prohibiting excess and wastefulness—calling humanity toward balance rather than indulgence.',
      hi: 'क़ुरआन 7:31 जीवन की अच्छी चीज़ों का आनंद लेने की अनुमति देते हुए अति और फिजूलखर्ची से बचने का निर्देश देता है—जो संतुलित संयम का मार्ग है।',
    },
    gitaExplanation: {
      en: 'In Bhagavad Gita 6:35, Krishna acknowledges that the mind is restless and hard to tame, yet affirms that it can be mastered through steady practice (abhyasa) and detachment (vairagya).',
      hi: 'भगवद्गीता 6:35 में यह स्वीकार किया गया है कि मन चंचल और कठिन है, किंतु निरंतर अभ्यास और वैराग्य (आसक्ति-त्याग) से इसे वश में किया जा सकता है।',
    },
    sharedPrinciple: {
      en: 'Both traditions recognize human appetite and mental restlessness, teaching moderation and disciplined habit over unchecked impulse.',
      hi: 'दोनों परंपराएँ मानवीय इच्छाओं और मन की चंचलता को समझती हैं तथा बेलगाम आवेगों के स्थान पर संतुलन और अभ्यास सिखाती हैं।',
    },
    differences: {
      en: 'The Quran emphasizes balanced stewardship of physical blessings (avoiding excess). The Gita offers a psychological method—repeated meditative practice and inner non-attachment—to quiet the mind.',
      hi: 'क़ुरआन भौतिक संसाधनों के संतुलित उपयोग पर बल देता है, जबकि गीता मन को शांत करने के लिए अभ्यास और वैराग्य की मानसिक विधि बताती है।',
    },
    practicalApplication: {
      en: 'Choose one daily habit—scrolling, spending, or impulsive eating—and practice a deliberate 10-second pause before acting.',
      hi: 'अपने किसी एक दैनिक आवेग (जैसे बिना सोचे बोलना, खर्च करना या स्क्रीन देखना) में आज 10 सेकंड रुककर सोचने का अभ्यास करें।',
    },
  },
  {
    id: 'humility',
    title: { en: 'Humility', hi: 'विनम्रता' },
    subtitle: {
      en: 'Walking gently without arrogance',
      hi: 'अहंकार त्यागकर सहज और विनम्र आचरण',
    },
    quranRef: { surah: 25, ayah: 63 },
    gitaRef: { chapter: 13, verse: 8 },
    quranExplanation: {
      en: 'Quran 25:63 portrays true servants of mercy as people who walk upon the earth with gentleness and humility, responding with peace even when provoked by harsh or ignorant speech.',
      hi: 'क़ुरआन 25:63 विनम्र लोगों का वर्णन करते हुए कहता है कि वे धरती पर सहजता और नम्रता से चलते हैं, और अज्ञानी या कटु लोगों के उकसाने पर भी शांति से उत्तर देते हैं।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 13:8 opens its definition of wisdom with humility (amanitvam), unpretentiousness, non-harm, and steadiness of mind.',
      hi: 'भगवद्गीता 13:8 सच्चे ज्ञान की शुरुआत ही विनम्रता (अमानित्व), आडंबरहीनता, अहिंसा और आत्म-संयम से करती है।',
    },
    sharedPrinciple: {
      en: 'Both scriptures treat humility not as low self-worth, but as the mark of a grounded, mature human being free from arrogance.',
      hi: 'दोनों ग्रंथ विनम्रता को हीनता नहीं, बल्कि अहंकार से मुक्त एक परिपक्व और ज्ञानी व्यक्ति का लक्षण मानते हैं।',
    },
    differences: {
      en: 'Quran 25:63 depicts humility through outward demeanor and calm speech toward others. Gita 13:8 frames humility as the inner foundation of philosophical wisdom and self-knowledge.',
      hi: 'क़ुरआन 25:63 विनम्रता को दूसरों के साथ शांत और सौम्य व्यवहार में दिखाता है, जबकि गीता 13:8 इसे आत्म-ज्ञान और विवेक की आधारशिला मानती है।',
    },
    practicalApplication: {
      en: 'In your next disagreement, resist the urge to prove superiority—listen fully first, and acknowledge if the other person makes a valid point.',
      hi: 'अगली किसी असहमति में खुद को श्रेष्ठ साबित करने के बजाय पहले सामने वाले को पूरा सुनें और उनकी सही बात को खुले मन से स्वीकार करें।',
    },
  },
  {
    id: 'duty-responsibility',
    title: { en: 'Duty and Responsibility', hi: 'कर्तव्य और उत्तरदायित्व' },
    subtitle: {
      en: 'Faithful action and honoring trusts',
      hi: 'ईमानदारी से अपना कर्तव्य निभाना',
    },
    quranRef: { surah: 4, ayah: 58 },
    gitaRef: { chapter: 2, verse: 47 },
    quranExplanation: {
      en: 'Quran 4:58 instructs people to return every trust (amanah) faithfully to those entitled to it and to judge fairly whenever entrusted with authority over others.',
      hi: 'क़ुरआन 4:58 अमानतों (जिम्मेदारियों और भरोसों) को उनके हकदारों तक ईमानदारी से पहुँचाने और अधिकार मिलने पर न्याय करने का निर्देश देता है।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 2:47 teaches that one has authority over one’s dedicated action, never over the ultimate outcome—urging sincere effort without anxiety-driven attachment or laziness.',
      hi: 'भगवद्गीता 2:47 का प्रसिद्ध उपदेश है कि मनुष्य का अधिकार केवल अपने कर्म पर है, उसके फल पर नहीं—इसलिए फल की चिंता छोड़कर निष्ठा से कर्म करना चाहिए।',
    },
    sharedPrinciple: {
      en: 'Both texts call humans to take full responsibility for their actions and obligations rather than fleeing duty or cutting ethical corners.',
      hi: 'दोनों ग्रंथ मनुष्य को अपने दायित्वों से भागने या अनैतिक शॉर्टकट लेने के बजाय पूरी निष्ठा से कर्तव्य निभाने की प्रेरणा देते हैं।',
    },
    differences: {
      en: 'Quran 4:58 focuses on relational and civic accountability ("trusts" owed to others). Gita 2:47 addresses the inner psychology of action—releasing attachment to results so duty stays pure.',
      hi: 'क़ुरआन 4:58 सामाजिक और पारस्परिक जवाबदेही ("अमानत") पर ध्यान देता है, जबकि गीता 2:47 कर्म करते समय फल की आसक्ति छोड़ने के मानसिक विज्ञान पर केंद्रित है।',
    },
    practicalApplication: {
      en: 'Give full care to the work entrusted to you today without obsessing over applause or immediate outcomes.',
      hi: 'आज आपके हिस्से में जो भी काम या जिम्मेदारी है, उसे बिना तुरंत प्रशंसा या परिणाम की चिंता किए पूरी ईमानदारी से पूरा करें।',
    },
  },
  {
    id: 'greed-attachment',
    title: { en: 'Greed and Attachment', hi: 'लोभ और आसक्ति' },
    subtitle: {
      en: 'When endless accumulation blinds the heart',
      hi: 'असीमित संग्रह और मोह का बंधन',
    },
    quranRef: { surah: 102, ayah: 1 },
    gitaRef: { chapter: 16, verse: 21 },
    quranExplanation: {
      en: 'Quran 102:1 diagnoses how compulsive competition for "more"—wealth, status, numbers—distracts people from what truly gives life meaning until time runs out.',
      hi: 'क़ुरआन 102:1 इस मानवीय प्रवृत्ति की ओर संकेत करता है कि अधिक से अधिक पाने की होड़ मनुष्य को जीवन के वास्तविक उद्देश्य से भटका देती है।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 16:21 identifies lust, anger, and greed as the threefold gate to inner ruin, urging individuals to recognize and abandon them for their own well-being.',
      hi: 'भगवद्गीता 16:21 काम, क्रोध और लोभ को आत्म-विनाश के तीन द्वार बताती है और कल्याण के लिए इनके त्याग का आग्रह करती है।',
    },
    sharedPrinciple: {
      en: 'Both traditions warn that unchecked greed and obsessive comparison rob the mind of peace and lead to ethical erosion.',
      hi: 'दोनों परंपराएँ सचेत करती हैं कि अनियंत्रित लोभ और तुलना की होड़ मन की शांति छीनकर व्यक्ति को नैतिक पतन की ओर ले जाती है।',
    },
    differences: {
      en: 'Quran 102:1 highlights social rivalry ("mutual rivalry in increase") and forgetfulness of mortality. Gita 16:21 analyzes greed alongside anger and desire as internal psychological forces destructive to the self.',
      hi: 'क़ुरआन 102:1 सामाजिक प्रतिस्पर्धा और जीवन की नश्वरता को भूलने पर जोर देता है, जबकि गीता 16:21 लोभ को काम और क्रोध के साथ आंतरिक मानसिक विकार के रूप में देखती है।',
    },
    practicalApplication: {
      en: 'Identify one area where comparison drives your dissatisfaction, and practice gratitude for what is already sufficient in your life.',
      hi: 'अपने जीवन के उस एक क्षेत्र को पहचानें जहाँ दूसरों से तुलना आपको अशांत कर रही है, और जो पर्याप्त है उसके प्रति कृतज्ञता का भाव लाएँ।',
    },
  },
  {
    id: 'anger-management',
    title: { en: 'Anger Management', hi: 'क्रोध प्रबंधन' },
    subtitle: {
      en: 'Restraining rage before it clouds judgment',
      hi: 'विवेक खोने से पहले क्रोध पर नियंत्रण',
    },
    quranRef: { surah: 3, ayah: 134 },
    gitaRef: { chapter: 2, verse: 63 },
    quranExplanation: {
      en: 'Quran 3:134 praises those who give generously in both ease and hardship, swallow their anger when provoked, and pardon people—describing such restraint as moral beauty.',
      hi: 'क़ुरआन 3:134 उन लोगों की प्रशंसा करता है जो सुख-दुख दोनों में उदार रहते हैं, क्रोध को पी जाते हैं और लोगों को क्षमा कर देते हैं।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 2:63 maps the psychological chain reaction of anger: anger creates delusion, delusion destroys memory of values, which leads to loss of discrimination and downfall.',
      hi: 'भगवद्गीता 2:63 क्रोध की मानसिक श्रृंखला समझाती है: क्रोध से मोह उत्पन्न होता है, मोह से स्मृति भ्रमित होती है, और उससे बुद्धि व विवेक का नाश हो जाता है।',
    },
    sharedPrinciple: {
      en: 'Both scriptures recognize anger as a pivotal test of character: restraining it protects both clarity of mind and harmony with others.',
      hi: 'दोनों ग्रंथ क्रोध को चरित्र की बड़ी परीक्षा मानते हैं: इसे संभालना मानसिक स्पष्टता और मानवीय संबंधों दोनों की रक्षा करता है।',
    },
    differences: {
      en: 'Quran 3:134 presents anger restraint together with active pardon and generosity. Gita 2:63 gives a step-by-step cognitive analysis of how unchecked anger dismantles human discernment.',
      hi: 'क़ुरआन 3:134 क्रोध पर काबू को क्षमा और उदारता से जोड़ता है, जबकि गीता 2:63 यह मनोवैज्ञानिक विश्लेषण देती है कि क्रोध किस तरह बुद्धि को नष्ट करता है।',
    },
    practicalApplication: {
      en: 'When anger surges, delay any reply for at least two minutes, breathe steadily, and separate the factual problem from the urge to strike back.',
      hi: 'जब क्रोध आए तो कम से कम दो मिनट तक कोई उत्तर न दें, गहरी सांस लें, और पलटवार करने के बजाय केवल वास्तविक समस्या पर ध्यान दें।',
    },
  },
  {
    id: 'peace-patience',
    title: { en: 'Peace and Patience', hi: 'शांति और धैर्य' },
    subtitle: {
      en: 'Steadiness amidst storms and uncertainty',
      hi: 'कठिनाइयों और अनिश्चितता में मन की स्थिरता',
    },
    quranRef: { surah: 94, ayah: 5 },
    gitaRef: { chapter: 2, verse: 56 },
    quranExplanation: {
      en: 'Quran 94:5 reassures the weary heart that ease accompanies hardship—not merely after it ends, but interwoven with endurance and quiet perseverance.',
      hi: 'क़ुरआन 94:5 थके हुए मन को आश्वस्त करता है कि कठिनाई के साथ ही आसानी भी है—धैर्य और उम्मीद के साथ हर कठिन दौर में राहत छिपी होती है।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 2:56 describes the person of steady wisdom as one whose mind remains unshaken in sorrow, free from craving in pleasure, and untouched by fear or rage.',
      hi: 'भगवद्गीता 2:56 स्थितप्रज्ञ व्यक्ति का वर्णन करती है जिसका मन दुखों में विचलित नहीं होता, सुख की लालसा से मुक्त रहता है और भय-क्रोध से परे होता है।',
    },
    sharedPrinciple: {
      en: 'Both traditions offer inner steadiness during adversity—teaching that turbulence outside need not dictate panic inside.',
      hi: 'दोनों परंपराएँ विपरीत परिस्थितियों में आंतरिक धैर्य सिखाती हैं—बाहरी उथल-पुथल के बावजूद भीतर शांत बने रहना संभव है।',
    },
    differences: {
      en: 'Quran 94:5 anchors patience in trust and hopeful resilience that relief stands alongside trial. Gita 2:56 anchors peace in philosophical equanimity toward both pleasure and pain.',
      hi: 'क़ुरआन 94:5 धैर्य को आशा और इस भरोसे से जोड़ता है कि कठिन समय में राहत साथ चलती है, जबकि गीता 2:56 सुख-दुख दोनों के प्रति समभाव को शांति का आधार मानती है।',
    },
    practicalApplication: {
      en: 'During a stressful day, focus only on the next honest step within your control rather than carrying an entire month of worry at once.',
      hi: 'तनावपूर्ण दिन में पूरे भविष्य की चिंता एक साथ उठाने के बजाय केवल अगले एक सही कदम पर ध्यान केंद्रित करें जो आपके नियंत्रण में है।',
    },
  },
  {
    id: 'respect-humanity',
    title: { en: 'Respect for Humanity', hi: 'मानवता का सम्मान' },
    subtitle: {
      en: 'Dignity across tribes, cultures, and backgrounds',
      hi: 'जाति, वर्ग और संस्कृति से परे हर मनुष्य की गरिमा',
    },
    quranRef: { surah: 49, ayah: 13 },
    gitaRef: { chapter: 12, verse: 13 },
    quranExplanation: {
      en: 'Quran 49:13 addresses all humankind directly, stating that human diversity of nations and tribes exists so people may know and understand one another—not despise one another—and that worth rests in moral conscience, not lineage.',
      hi: 'क़ुरआन 49:13 संपूर्ण मानवता को संबोधित करते हुए कहता है कि विभिन्न समुदाय और संस्कृतियाँ इसलिए बनाई गईं ताकि लोग एक-दूसरे को पहचानें और समझें, न कि घृणा करें; श्रेष्ठता का आधार आचरण है, वंश नहीं।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 12:13 (and 6:32) cultivates universal friendliness without enmity toward any living being, seeing shared dignity across outward differences.',
      hi: 'भगवद्गीता 12:13 सभी प्राणियों के प्रति मैत्री, करुणा और द्वेष-रहित दृष्टि की शिक्षा देती है, जो बाहरी भेदभाव से ऊपर उठती है।',
    },
    sharedPrinciple: {
      en: 'Both texts reject contempt based on birth, tribe, or status, affirming universal human dignity and mutual respect.',
      hi: 'दोनों ग्रंथ जन्म, जाति या वर्ग के आधार पर किसी भी तिरस्कार को अस्वीकार करते हैं और सभी मनुष्यों के सम्मान का समर्थन करते हैं।',
    },
    differences: {
      en: 'Quran 49:13 explicitly celebrates cultural and social plurality as an intentional design for mutual learning. The Gita emphasizes inward universal empathy—seeing every being with an equal, non-hostile eye.',
      hi: 'क़ुरआन 49:13 सांस्कृतिक विविधता को आपसी परिचय और संवाद के अवसर के रूप में देखता है, जबकि गीता प्रत्येक प्राणी में समान भाव और मैत्री की आंतरिक दृष्टि विकसित करने पर बल देती है।',
    },
    practicalApplication: {
      en: 'Make space to listen respectfully to someone whose background or worldview differs from yours, seeking understanding rather than debate.',
      hi: 'किसी ऐसे व्यक्ति की बात ध्यान से सुनें जिसकी पृष्ठभूमि या विचार आपसे अलग हों—बहस के बजाय समझने का प्रयास करें।',
    },
  },
  {
    id: 'helping-others',
    title: { en: 'Helping Others', hi: 'परोपकार और सेवा' },
    subtitle: {
      en: 'Service toward the vulnerable and society',
      hi: 'जरूरतमंदों की सहायता और समाज कल्याण',
    },
    quranRef: { surah: 2, ayah: 177 },
    gitaRef: { chapter: 3, verse: 25 },
    quranExplanation: {
      en: 'Quran 2:177 clarifies that true righteousness is not merely turning toward a ritual direction, but sharing wealth out of love with relatives, orphans, the needy, travelers, and those seeking freedom.',
      hi: 'क़ुरआन 2:177 स्पष्ट करता है कि सच्ची नेकी केवल बाहरी दिशा या औपचारिकता में नहीं, बल्कि संबंधियों, अनाथों, जरूरतमंदों और यात्रियों की निःस्वार्थ सहायता में है।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 3:25 calls wise individuals to act selflessly without attachment, motivated by "lokasangraha"—the welfare and cohesion of the entire world.',
      hi: 'भगवद्गीता 3:25 ज्ञानी व्यक्तियों को "लोकसंग्रह" अर्थात संपूर्ण समाज के कल्याण और संतुलन के लिए बिना स्वार्थ कर्म करने की प्रेरणा देती है।',
    },
    sharedPrinciple: {
      en: 'Both scriptures declare that genuine spirituality expresses itself through tangible care for society and vulnerable neighbors.',
      hi: 'दोनों ग्रंथ मानते हैं कि सच्ची आध्यात्मिकता समाज के कमजोर वर्गों की ठोस सेवा और लोक-कल्याण में प्रकट होती है।',
    },
    differences: {
      en: 'Quran 2:177 specifies concrete social categories in need of economic care alongside fulfilling promises. Gita 3:25 frames service philosophically around acting for global welfare ("lokasangraha") as an example to others.',
      hi: 'क़ुरआन 2:177 आर्थिक सहयोग और वचन निभाने के ठोस सामाजिक दायित्व बताता है, जबकि गीता 3:25 लोक-कल्याण और समाज के सामने श्रेष्ठ उदाहरण रखने के सिद्धांत पर जोर देती है।',
    },
    practicalApplication: {
      en: 'Dedicate part of your time, skill, or resources this week to helping someone who cannot repay the favor.',
      hi: 'इस सप्ताह अपने समय, कौशल या संसाधनों का एक हिस्सा किसी ऐसे व्यक्ति की मदद में लगाएँ जो बदले में आपको कुछ न दे सके।',
    },
  },
  {
    id: 'integrity',
    title: { en: 'Integrity', hi: 'ईमानदारी और चरित्र' },
    subtitle: {
      en: 'Consistency between private conscience and public trust',
      hi: 'कथनी और करनी की एकता',
    },
    quranRef: { surah: 28, ayah: 26 },
    gitaRef: { chapter: 16, verse: 2 },
    quranExplanation: {
      en: 'Quran 28:26 highlights the two pillars of trustworthy character in leadership and work: capability ("strong") paired with moral reliability ("trustworthy").',
      hi: 'क़ुरआन 28:26 कार्य और नेतृत्व में विश्वसनीय चरित्र के दो आधार बताता है: कार्यक्षमता (सक्षम) और नैतिक ईमानदारी (भरोसेमंद)।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 16:2 pairs truthfulness, absence of crookedness (ajarjavam), non-violence, and peace as essential traits of an integrated ethical life.',
      hi: 'भगवद्गीता 16:2 सत्य, सरलता (कुटिलता का अभाव), अहिंसा और शांति को एक सशक्त नैतिक जीवन के मूल स्तंभ बताती है।',
    },
    sharedPrinciple: {
      en: 'Both traditions teach that competence without honesty is hollow, and upright character means remaining straightforward when no one is watching.',
      hi: 'दोनों परंपराएँ मानती हैं कि बिना ईमानदारी के योग्यता अधूरी है, और सच्चा चरित्र वही है जो एकांत में भी सीधा और पारदर्शी रहे।',
    },
    differences: {
      en: 'Quran 28:26 draws integrity from a practical narrative about employment and civic trust. Gita 16:2 lists uprightness ("absence of crookedness") among internal virtues cultivated through self-discipline.',
      hi: 'क़ुरआन 28:26 इसे कार्यस्थल और सामाजिक भरोसे की एक व्यावहारिक घटना से जोड़ता है, जबकि गीता 16:2 सरलता और निष्कपटता को आंतरिक सद्गुणों की सूची में रखती है।',
    },
    practicalApplication: {
      en: 'Keep one small promise you made to yourself or someone else today, even if nobody would notice if you skipped it.',
      hi: 'आज खुद से या किसी और से किया गया एक छोटा वादा पूरी निष्ठा से निभाएँ, भले ही उसे टालने पर किसी को पता न चले।',
    },
  },
  {
    id: 'purpose-of-life',
    title: { en: 'Purpose of Life', hi: 'जीवन का उद्देश्य' },
    subtitle: {
      en: 'Meaningful living beyond fleeting distraction',
      hi: 'क्षणिक भटकाव से परे सार्थक जीवन',
    },
    quranRef: { surah: 103, ayah: 3 },
    gitaRef: { chapter: 18, verse: 46 },
    quranExplanation: {
      en: 'Surah Al-Asr (103:1–3) warns that humanity drifts toward loss unless anchored in faith, righteous deeds, mutual counsel toward truth, and mutual counsel toward patience.',
      hi: 'सूरह अल-अस्र (103:1–3) कहती है कि मनुष्य समय के साथ घाटे में रहता है, सिवाय उनके जो सद्कर्म करें, तथा एक-दूसरे को सत्य और धैर्य की सलाह दें।',
    },
    gitaExplanation: {
      en: 'Bhagavad Gita 18:46 teaches that a person attains fulfillment by offering their own natural work and duty in harmony with the Divine source from which all beings emerge.',
      hi: 'भगवद्गीता 18:46 सिखाती है कि मनुष्य अपने स्वाभाविक कर्म और कर्तव्य को उस परम सत्ता को समर्पित करके ही जीवन की पूर्णता प्राप्त करता है जिससे सब उत्पन्न हुए हैं।',
    },
    sharedPrinciple: {
      en: 'Both scriptures teach that human life finds enduring purpose not in self-centered accumulation, but in ethical action, truthfulness, and service aligned with higher meaning.',
      hi: 'दोनों ग्रंथ मानते हैं कि जीवन की सार्थकता स्वार्थी संग्रह में नहीं, बल्कि नैतिक कर्म, सत्य, धैर्य और उच्चतर उद्देश्य के साथ जीने में है।',
    },
    differences: {
      en: 'Quran 103:3 emphasizes communal moral accountability—truth and patience shared together in society. Gita 18:46 emphasizes discovering one’s own authentic calling (svakarma) and dedicating it spiritually.',
      hi: 'क़ुरआन 103:3 सामूहिक नैतिक जिम्मेदारी (समाज में सत्य और धैर्य को बढ़ावा देना) पर केंद्रित है, जबकि गीता 18:46 अपने स्वकर्म की पहचान और उसके समर्पण पर बल देती है।',
    },
    practicalApplication: {
      en: 'Reflect tonight on one skill you possess and one relationship you cherish—ask how both can serve truth and patience tomorrow.',
      hi: 'आज रात अपने एक कौशल और एक महत्वपूर्ण रिश्ते के बारे में सोचें—और तय करें कि कल वे दोनों सत्य और धैर्य की सेवा कैसे कर सकते हैं।',
    },
  },
];

const SITUATION_CATEGORIES: SituationCategoryRaw[] = [
  {
    id: 'relationships',
    title: { en: 'Relationships', hi: 'रिश्ते' },
    summary: {
      en: 'Navigating hurt, communication, empathy, and reconciliation.',
      hi: 'संबंधों में संवाद, संवेदनशीलता, चोट और मेल-मिलाप।',
    },
    quranRefs: [
      { surah: 41, ayah: 34 },
      { surah: 3, ayah: 159 },
    ],
    gitaRefs: [
      { chapter: 12, verse: 13 },
      { chapter: 17, verse: 15 },
    ],
    reflection: {
      en: 'Healthy relationships ask us to pair honesty with gentleness. Both scriptures remind us that harshness pushes hearts away, while steady goodwill can disarm hostility without sacrificing self-respect.',
      hi: 'स्वस्थ रिश्तों में ईमानदारी और कोमलता का संतुलन जरूरी है। दोनों ग्रंथ सिखाते हैं कि कठोर वाणी दूरियाँ बढ़ाती है, जबकि शांत सद्भावना कटुता को कम कर सकती है।',
    },
    practicalSteps: {
      en: [
        'Listen to understand before defending your position.',
        'Speak honestly without using hurtful or humiliating words.',
        'Pause before replying when emotions run high.',
      ],
      hi: [
        'अपना पक्ष रखने से पहले सामने वाले की बात को समझने के लिए सुनें।',
        'सत्य कहें, लेकिन अपमानजनक या आहत करने वाले शब्दों से बचें।',
        'भावनाएँ तीव्र होने पर तुरंत प्रतिक्रिया देने से रुकें।',
      ],
    },
  },
  {
    id: 'family',
    title: { en: 'Family', hi: 'परिवार' },
    summary: {
      en: 'Honoring parents, resolving household tension, and caring across generations.',
      hi: 'माता-पिता का सम्मान, पारिवारिक तनाव और पीढ़ियों के बीच देखभाल।',
    },
    quranRefs: [
      { surah: 17, ayah: 23 },
      { surah: 16, ayah: 90 },
    ],
    gitaRefs: [
      { chapter: 13, verse: 8 },
      { chapter: 17, verse: 15 },
    ],
    reflection: {
      en: 'Family bonds often test our patience most closely because familiarity lowers our guard. Gratitude toward parents and elders, paired with humble, unagitated speech, builds peace at home.',
      hi: 'परिवार में धैर्य की सबसे बड़ी परीक्षा होती है। माता-पिता के प्रति कृतज्ञता और विनम्र, शांत वाणी घर में शांति की नींव रखती है।',
    },
    practicalSteps: {
      en: [
        'Offer time and attentive presence to elders, not just material support.',
        'Drop sarcasm or sharp tone during household disagreements.',
        'Practice patience with generational differences in perspective.',
      ],
      hi: [
        'बड़ों को केवल संसाधन ही नहीं, अपना समय और संवेदनशील साथ भी दें।',
        'घरेलू मतभेदों में व्यंग्य या तीखे लहजे से बचें।',
        'पीढ़ियों के विचारों के अंतर के प्रति धैर्य रखें।',
      ],
    },
  },
  {
    id: 'career',
    title: { en: 'Career', hi: 'करियर और कार्य' },
    summary: {
      en: 'Purposeful work, burnout, comparison, and ethical leadership.',
      hi: 'सार्थक कार्य, थकान, तुलना और नैतिक नेतृत्व।',
    },
    quranRefs: [
      { surah: 28, ayah: 26 },
      { surah: 29, ayah: 69 },
    ],
    gitaRefs: [
      { chapter: 2, verse: 47 },
      { chapter: 3, verse: 19 },
    ],
    reflection: {
      en: 'Sustainable work integrates competence, trustworthiness, and freedom from outcome-obsession. When effort is sincere and unattached to ego, setbacks become lessons rather than identity crises.',
      hi: 'सार्थक कार्य में दक्षता, विश्वसनीयता और परिणाम की अत्यधिक चिंता से मुक्ति का मेल होता है। जब प्रयास ईमानदार हो, तो असफलता भी सीख बन जाती है।',
    },
    practicalSteps: {
      en: [
        'Measure your day by the integrity of your effort, not only external applause.',
        'Honor commitments and deadlines as moral trusts.',
        'Step back from toxic workplace comparison.',
      ],
      hi: [
        'अपने दिन का मूल्यांकन केवल बाहरी प्रशंसा से नहीं, अपने प्रयास की ईमानदारी से करें।',
        'कार्यस्थल पर किए गए वादों और समय-सीमा को अमानत मानकर निभाएँ।',
        'अनावश्यक तुलना की दौड़ से खुद को दूर रखें।',
      ],
    },
  },
  {
    id: 'financial-struggles',
    title: { en: 'Financial Struggles', hi: 'आर्थिक कठिनाइयाँ' },
    summary: {
      en: 'Navigating scarcity, debt stress, balance, and resilience.',
      hi: 'आर्थिक तंगी, तनाव, संतुलन और धैर्य।',
    },
    quranRefs: [
      { surah: 65, ayah: 3 },
      { surah: 28, ayah: 77 },
    ],
    gitaRefs: [
      { chapter: 2, verse: 48 },
      { chapter: 16, verse: 21 },
    ],
    reflection: {
      en: 'Financial hardship weighs heavily on dignity and peace of mind. Scripture reminds us not to equate human worth with bank balance, while encouraging disciplined planning, patience, and seeking grounded support.',
      hi: 'आर्थिक कठिनाई मन पर गहरा दबाव डालती है। ग्रंथ हमें याद दिलाते हैं कि मनुष्य का मूल्य केवल धन से तय नहीं होता, साथ ही संतुलन और धैर्य के साथ व्यावहारिक कदम उठाना जरूरी है।',
    },
    practicalSteps: {
      en: [
        'Separate your self-worth from temporary financial loss.',
        'Cut comparison-driven spending and prioritize essential stability.',
        'Consult a qualified financial advisor or debt counselor for concrete planning.',
      ],
      hi: [
        'अस्थायी आर्थिक नुकसान को अपने आत्म-सम्मान का मापदंड न बनाएँ।',
        'दिखावे और तुलना से प्रेरित खर्चों को रोककर बुनियादी स्थिरता पर ध्यान दें।',
        'ठोस योजना के लिए किसी योग्य वित्तीय सलाहकार से मार्गदर्शन लें।',
      ],
    },
  },
  {
    id: 'fear-anxiety',
    title: { en: 'Fear and Anxiety', hi: 'भय और चिंता' },
    summary: {
      en: 'Calming an overwhelmed mind during uncertainty.',
      hi: 'अनिश्चितता के समय व्याकुल मन को शांत करना।',
    },
    quranRefs: [
      { surah: 13, ayah: 28 },
      { surah: 2, ayah: 286 },
    ],
    gitaRefs: [
      { chapter: 6, verse: 35 },
      { chapter: 16, verse: 1 },
    ],
    reflection: {
      en: 'Anxiety multiplies when the mind tries to live through imagined futures all at once. Grounding attention in the present, gentle remembrance, and steady breathing restore perspective. For persistent panic or severe distress, professional mental health care is vital.',
      hi: 'चिंता तब बढ़ती है जब मन एक साथ आने वाले कल के सारे डर जीने लगता है। वर्तमान में लौटना और शांत अभ्यास मन को संभालता है। यदि घबराहट लगातार बनी रहे तो चिकित्सक या परामर्शदाता की मदद अवश्य लें।',
    },
    practicalSteps: {
      en: [
        'Anchor attention in what is true and manageable right now.',
        'Practice 5 minutes of quiet breathing or contemplative stillness daily.',
        'Reach out to a doctor or counselor if anxiety disrupts sleep or daily functioning.',
      ],
      hi: [
        'अपना ध्यान इस बात पर लाएँ कि अभी इस पल क्या सत्य और संभालने योग्य है।',
        'प्रतिदिन 5 मिनट शांत सांस लेने या मौन चिंतन का अभ्यास करें।',
        'यदि चिंता नींद या दैनिक जीवन को प्रभावित करे, तो विशेषज्ञ की सलाह लें।',
      ],
    },
  },
  {
    id: 'anger',
    title: { en: 'Anger', hi: 'क्रोध' },
    summary: {
      en: 'Interrupting reactivity before regret follows.',
      hi: 'पछतावे से पहले तीव्र प्रतिक्रिया को रोकना।',
    },
    quranRefs: [
      { surah: 3, ayah: 134 },
      { surah: 41, ayah: 34 },
    ],
    gitaRefs: [
      { chapter: 2, verse: 62 },
      { chapter: 2, verse: 63 },
    ],
    reflection: {
      en: 'Anger often masks hurt, fear, or bruised pride. Seeing how quickly rage clouds memory and reason empowers us to pause before speaking words we cannot take back.',
      hi: 'क्रोध के पीछे अक्सर आहत भावना, भय या अहंकार छिपा होता है। यह समझना कि क्रोध बुद्धि को कैसे ढँक लेता है, हमें अपशब्द कहने से पहले रुकने की शक्ति देता है।',
    },
    practicalSteps: {
      en: [
        'Step away physically or stay silent until your pulse settles.',
        'Name the underlying emotion (hurt, stress, helplessness) beneath the anger.',
        'Address the issue calmly once clarity returns.',
      ],
      hi: [
        'जब तक मन शांत न हो, कुछ क्षण के लिए स्थान बदल दें या मौन रहें।',
        'क्रोध के नीचे छिपी मूल भावना (दर्द, तनाव या असहायता) को पहचानें।',
        'स्पष्टता लौटने पर ही मुद्दे पर शांत संवाद करें।',
      ],
    },
  },
  {
    id: 'failure',
    title: { en: 'Failure', hi: 'विफलता' },
    summary: {
      en: 'Rising after disappointment with steadiness.',
      hi: 'निराशा और हार के बाद फिर से संभलना।',
    },
    quranRefs: [
      { surah: 94, ayah: 5 },
      { surah: 2, ayah: 286 },
    ],
    gitaRefs: [
      { chapter: 2, verse: 48 },
      { chapter: 6, verse: 5 },
    ],
    reflection: {
      en: 'A failed attempt is an event, not a verdict on your humanity. Gita 6:5 urges us to lift ourselves by our own inner ally, while Quran 94:5 reminds us that ease is already woven beside hardship.',
      hi: 'किसी प्रयास का विफल होना एक घटना है, आपके पूरे जीवन का अंतिम निर्णय नहीं। गीता 6:5 स्वयं को स्वयं के द्वारा ऊपर उठाने की प्रेरणा देती है, और क़ुरआन 94:5 कठिन समय के साथ राहत का भरोसा देता है।',
    },
    practicalSteps: {
      en: [
        'Review what happened objectively without harsh self-condemnation.',
        'Identify one lesson and one small next step.',
        'Accept that growth rarely moves in a straight line.',
      ],
      hi: [
        'स्वयं को कोसे बिना निष्पक्ष होकर देखें कि कहाँ सुधार की गुंजाइश थी।',
        'अनुभव से एक सीख और अगला एक छोटा कदम तय करें।',
        'स्वीकार करें कि विकास की राह हमेशा सीधी नहीं होती।',
      ],
    },
  },
  {
    id: 'loneliness',
    title: { en: 'Loneliness', hi: 'अकेलापन' },
    summary: {
      en: 'Finding inner companionship and meaningful connection.',
      hi: 'आंतरिक जुड़ाव और सार्थक मानवीय संबंध।',
    },
    quranRefs: [
      { surah: 13, ayah: 28 },
      { surah: 2, ayah: 153 },
    ],
    gitaRefs: [
      { chapter: 6, verse: 5 },
      { chapter: 12, verse: 13 },
    ],
    reflection: {
      en: 'Loneliness hurts deeply, whether alone in a room or unseen in a crowd. Becoming a gentle friend to oneself while extending genuine kindness toward another person gradually softens isolation.',
      hi: 'अकेलापन गहरा दर्द देता है। स्वयं के प्रति करुणा और मित्रता विकसित करना तथा किसी दूसरे की ओर निस्वार्थ मदद का हाथ बढ़ाना इस एकाकीपन को कम करता है।',
    },
    practicalSteps: {
      en: [
        'Send one genuine check-in message to a friend, relative, or neighbor.',
        'Join a community or volunteer space centered on shared service.',
        'Speak to yourself with the same warmth you offer others.',
      ],
      hi: [
        'किसी मित्र, परिजन या पड़ोसी को सच्चे मन से हालचाल पूछने का संदेश भेजें।',
        'सेवा या साझा रुचि वाले किसी सकारात्मक समूह से जुड़ें।',
        'स्वयं से उसी उदारता से बात करें जैसे किसी प्रिय मित्र से करते हैं।',
      ],
    },
  },
  {
    id: 'personal-growth',
    title: { en: 'Personal Growth', hi: 'आत्म-विकास' },
    summary: {
      en: 'Building character, discipline, and clarity day by day.',
      hi: 'दैनिक जीवन में चरित्र, अनुशासन और विवेक का निर्माण।',
    },
    quranRefs: [
      { surah: 29, ayah: 69 },
      { surah: 103, ayah: 3 },
    ],
    gitaRefs: [
      { chapter: 6, verse: 5 },
      { chapter: 18, verse: 37 },
    ],
    reflection: {
      en: 'Gita 18:37 notes that enduring clarity often feels demanding like poison at first before becoming deeply nourishing like nectar. Honest daily effort transforms habit into character.',
      hi: 'गीता 18:37 बताती है कि आत्म-विकास का अनुशासन शुरुआत में कठिन लग सकता है, पर अंत में अमृत समान सुख देता है। निरंतर प्रयास ही चरित्र गढ़ता है।',
    },
    practicalSteps: {
      en: [
        'Choose one small discipline you can sustain for 30 days rather than dramatic promises.',
        'Surround yourself with people who value truth and patience.',
        'Reflect for 3 minutes each evening on one thing you handled well and one to refine.',
      ],
      hi: [
        'बड़े-बड़े वादों के बजाय एक छोटा अनुशासन चुनें जिसे आप 30 दिन निभा सकें।',
        'ऐसे लोगों की संगति चुनें जो सत्य और धैर्य को महत्व देते हैं।',
        'प्रतिदिन रात को 3 मिनट अपने दिन के व्यवहार पर शांत चिंतन करें।',
      ],
    },
  },
  {
    id: 'ethics-decisions',
    title: { en: 'Ethics and Decisions', hi: 'नैतिकता और निर्णय' },
    summary: {
      en: 'Choosing right over convenient when gray areas arise.',
      hi: 'दुविधा के समय सुविधा के बजाय सही मार्ग चुनना।',
    },
    quranRefs: [
      { surah: 4, ayah: 135 },
      { surah: 2, ayah: 42 },
    ],
    gitaRefs: [
      { chapter: 3, verse: 19 },
      { chapter: 16, verse: 2 },
    ],
    reflection: {
      en: 'Ethical dilemmas test whether we bend principles for comfort. Clarity emerges when we strip away vanity and ask: is this truthful, fair to the vulnerable, and free from harm?',
      hi: 'नैतिक दुविधाएँ हमारी सच्चाई की परीक्षा लेती हैं। जब हम स्वार्थ और दिखावे को हटाकर पूछते हैं कि क्या यह सत्य, न्यायपूर्ण और अहिंसक है, तो सही रास्ता स्पष्ट हो जाता है।',
    },
    practicalSteps: {
      en: [
        'Ask whether you would stand by this choice if it were made completely public.',
        'Check who bears the hidden cost of a convenient shortcut.',
        'Seek counsel from someone known for integrity, not flattery.',
      ],
      hi: [
        'स्वयं से पूछें कि यदि यह निर्णय सबके सामने आ जाए, तो क्या आप उस पर गर्व कर पाएँगे।',
        'देखें कि किसी आसान शॉर्टकट की अनदेखी कीमत किसे चुकानी पड़ रही है।',
        'चापलूसों से नहीं, किसी ईमानदार और निष्पक्ष व्यक्ति से सलाह लें।',
      ],
    },
  },
  {
    id: 'social-responsibility',
    title: { en: 'Social Responsibility', hi: 'सामाजिक दायित्व' },
    summary: {
      en: 'Contributing to fairness, dignity, and collective well-being.',
      hi: 'समाज में न्याय, सम्मान और सामूहिक कल्याण में योगदान।',
    },
    quranRefs: [
      { surah: 2, ayah: 177 },
      { surah: 49, ayah: 13 },
    ],
    gitaRefs: [
      { chapter: 3, verse: 25 },
      { chapter: 17, verse: 20 },
    ],
    reflection: {
      en: 'Neither tradition permits spiritual indifference toward human suffering. Serving society, protecting the vulnerable, and fostering mutual respect across differences belong to everyday moral life.',
      hi: 'दोनों ही परंपराएँ मानवीय दुख के प्रति उदासीनता को स्वीकार नहीं करतीं। समाज की सेवा, कमजोरों की रक्षा और विविधता के बीच सम्मान हर व्यक्ति का दायित्व है।',
    },
    practicalSteps: {
      en: [
        'Support local initiatives aiding education, food security, or dignified work.',
        'Speak up calmly against dehumanizing language toward any group.',
        'Share resources transparently without seeking recognition.',
      ],
      hi: [
        'शिक्षा, भोजन या सम्मानजनक आजीविका में मदद करने वाली स्थानीय पहलों का सहयोग करें।',
        'किसी भी समुदाय के प्रति अपमानजनक भाषा का शांत व दृढ़ विरोध करें।',
        'बिना श्रेय की अपेक्षा के अपने संसाधनों को साझा करें।',
      ],
    },
  },
];

export function getOneHumanityTopics() {
  return ONE_HUMANITY_TOPICS.map((t) => {
    const quranVerse = hydrateQuranVerse(t.quranRef.surah, t.quranRef.ayah);
    const gitaVerse = hydrateGitaVerse(t.gitaRef.chapter, t.gitaRef.verse);
    return {
      id: t.id,
      title: t.title,
      subtitle: t.subtitle,
      quranVerse,
      gitaVerse,
      quranExplanation: t.quranExplanation,
      gitaExplanation: t.gitaExplanation,
      sharedPrinciple: t.sharedPrinciple,
      differences: t.differences,
      practicalApplication: t.practicalApplication,
    };
  });
}

export function getSituationCategories() {
  return SITUATION_CATEGORIES.map((c) => {
    const quranVerses: HydratedVerse[] = [];
    for (const ref of c.quranRefs) {
      const v = hydrateQuranVerse(ref.surah, ref.ayah);
      if (v) quranVerses.push(v);
    }
    const gitaVerses: HydratedVerse[] = [];
    for (const ref of c.gitaRefs) {
      const v = hydrateGitaVerse(ref.chapter, ref.verse);
      if (v) gitaVerses.push(v);
    }
    return {
      id: c.id,
      title: c.title,
      summary: c.summary,
      quranVerses,
      gitaVerses,
      reflection: c.reflection,
      practicalSteps: c.practicalSteps,
    };
  });
}

export function getDailyWisdom(dateStr?: string) {
  const topics = getOneHumanityTopics();
  const key = dateStr || new Date().toISOString().slice(0, 10);
  let hash = 0;
  for (let i = 0; i < key.length; i++) {
    hash = (hash * 31 + key.charCodeAt(i)) % 100000;
  }
  const topic = topics[hash % topics.length];
  return {
    date: key,
    topicId: topic.id,
    title: topic.title,
    subtitle: topic.subtitle,
    quranVerse: topic.quranVerse,
    gitaVerse: topic.gitaVerse,
    sharedPrinciple: topic.sharedPrinciple,
  };
}
