import { useEffect, useState } from 'react';
import {
  Bookmark,
  BookOpen,
  Compass,
  Home,
  MessageSquareHeart,
  Scale,
  User,
  WifiOff,
} from 'lucide-react';
import {
  AppLang,
  BookmarkItem,
  DailyWisdom,
  HydratedVerse,
  NavTab,
  OneHumanityTopic,
  ReadingPreferences,
  SituationCategory,
} from './types';
import { UI_COPY } from './i18n/translations';
import { OnboardingModal } from './components/OnboardingModal';
import { HomeView } from './components/HomeView';
import { ScripturesView } from './components/ScripturesView';
import { OneHumanityView } from './components/OneHumanityView';
import { AskReliefView } from './components/AskReliefView';
import { BookmarksView } from './components/BookmarksView';
import { ProfileView } from './components/ProfileView';

const STORAGE_KEYS = {
  lang: 'relief_lang_v1',
  bookmarks: 'relief_bookmarks_v1',
  prefs: 'relief_prefs_v1',
  onboarded: 'relief_onboarded_v1',
};

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [lang, setLang] = useState<AppLang>(() =>
    readStorage<AppLang>(STORAGE_KEYS.lang, 'en')
  );
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [activeScripture, setActiveScripture] = useState<'quran' | 'gita'>('quran');
  const [selectedHumanityTopicId, setSelectedHumanityTopicId] =
    useState<string>('compassion');
  const [pendingAskQuestion, setPendingAskQuestion] = useState<string | null>(null);

  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(() =>
    readStorage<BookmarkItem[]>(STORAGE_KEYS.bookmarks, [])
  );
  const [preferences, setPreferences] = useState<ReadingPreferences>(() =>
    readStorage<ReadingPreferences>(STORAGE_KEYS.prefs, {
      showOriginalScript: true,
      showTransliteration: true,
      showDualTranslation: true,
    })
  );
  const [showOnboarding, setShowOnboarding] = useState<boolean>(
    () => !readStorage<boolean>(STORAGE_KEYS.onboarded, false)
  );
  const [isOffline, setIsOffline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );

  // Shared core datasets loaded once
  const [dailyWisdom, setDailyWisdom] = useState<DailyWisdom | null>(null);
  const [oneHumanityTopics, setOneHumanityTopics] = useState<OneHumanityTopic[]>([]);
  const [situations, setSituations] = useState<SituationCategory[]>([]);
  const [loadingInitial, setLoadingInitial] = useState(true);

  const t = UI_COPY[lang];

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.lang, JSON.stringify(lang));
      document.documentElement.lang = lang;
    } catch {
      // Ignore storage errors
    }
  }, [lang]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.bookmarks, JSON.stringify(bookmarks));
    } catch {
      // Ignore storage errors
    }
  }, [bookmarks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.prefs, JSON.stringify(preferences));
    } catch {
      // Ignore storage errors
    }
  }, [preferences]);

  useEffect(() => {
    const onOnline = () => setIsOffline(false);
    const onOffline = () => setIsOffline(true);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  useEffect(() => {
    let mounted = true;
    setLoadingInitial(true);
    Promise.all([
      fetch('/api/daily-wisdom').then((r) => r.json()),
      fetch('/api/one-humanity').then((r) => r.json()),
      fetch('/api/situations').then((r) => r.json()),
    ])
      .then(([dw, oh, sit]) => {
        if (!mounted) return;
        setDailyWisdom(dw as DailyWisdom);
        setOneHumanityTopics((oh.topics || []) as OneHumanityTopic[]);
        setSituations((sit.categories || []) as SituationCategory[]);
      })
      .catch(() => {
        // Offline or network transient; handled via offline banner
      })
      .finally(() => {
        if (mounted) setLoadingInitial(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const isBookmarked = (id: string) => bookmarks.some((b) => b.verse.id === id);

  const handleToggleBookmark = (verse: HydratedVerse) => {
    setBookmarks((prev) => {
      const exists = prev.some((b) => b.verse.id === verse.id);
      if (exists) {
        return prev.filter((b) => b.verse.id !== verse.id);
      }
      return [{ verse, savedAt: new Date().toISOString() }, ...prev];
    });
  };

  const handleUpdateBookmarkNote = (id: string, note: string) => {
    setBookmarks((prev) =>
      prev.map((item) => (item.verse.id === id ? { ...item, note } : item))
    );
  };

  const handleNavigate = (tab: NavTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenScripture = (scripture: 'quran' | 'gita') => {
    setActiveScripture(scripture);
    handleNavigate('scriptures');
  };

  const handleOpenOneHumanityTopic = (topicId: string) => {
    setSelectedHumanityTopicId(topicId);
    handleNavigate('one-humanity');
  };

  const handleAskQuestion = (question: string) => {
    setPendingAskQuestion(question);
    handleNavigate('ask-relief');
  };

  const handleCompleteOnboarding = () => {
    try {
      localStorage.setItem(STORAGE_KEYS.onboarded, JSON.stringify(true));
    } catch {
      // Ignore storage errors
    }
    setShowOnboarding(false);
  };

  const desktopNavItems: Array<{ id: NavTab; label: string }> = [
    { id: 'home', label: t.nav.home },
    { id: 'scriptures', label: t.nav.scriptures },
    { id: 'one-humanity', label: t.nav.oneHumanity },
    { id: 'ask-relief', label: t.nav.askRelief },
    { id: 'bookmarks', label: t.nav.bookmarks },
  ];

  const mobileTabs: Array<{ id: NavTab; label: string; icon: typeof Home }> = [
    { id: 'home', label: t.nav.home, icon: Home },
    { id: 'scriptures', label: t.nav.scriptures, icon: BookOpen },
    { id: 'one-humanity', label: t.nav.oneHumanity, icon: Scale },
    { id: 'ask-relief', label: t.nav.askRelief, icon: MessageSquareHeart },
    { id: 'bookmarks', label: t.nav.bookmarks, icon: Bookmark },
  ];

  return (
    <div className="min-h-screen bg-[#0D0E11] text-[#F3F0E8] flex flex-col">
      {/* Desktop Top Bar (3-Zone Contract) & Mobile Top Bar */}
      <header className="sticky top-0 z-30 bg-[#0D0E11]/90 backdrop-blur-md border-b border-[#F3F0E8]/8 pt-safe">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 md:h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => handleNavigate('home')}
            className="font-display text-xl md:text-2xl font-semibold tracking-wider text-[#F3F0E8] hover:text-[#C9A449] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {t.brand}
          </button>

          {/* Zone 2: Desktop Concise Single-Line Nav Links */}
          <nav
            aria-label="Primary"
            className="hidden md:flex items-center gap-7"
          >
            {desktopNavItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`relative py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'text-[#C9A449]'
                      : 'text-[#A6A197] hover:text-[#F3F0E8]'
                  }`}
                >
                  <span>{item.label}</span>
                  {active && (
                    <span className="absolute left-0 right-0 -bottom-[1px] h-[2px] bg-[#C9A449]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single Primary Action (Profile & Language) */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => handleNavigate('profile')}
              aria-label={t.nav.profile}
              className={`min-h-[44px] min-w-[44px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'profile'
                  ? 'bg-[#C9A449] text-[#0D0E11]'
                  : 'border border-[#F3F0E8]/15 text-[#F3F0E8] hover:border-[#C9A449]'
              }`}
            >
              <User className="w-4 h-4" />
              <span className="hidden sm:inline">{t.nav.profile}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Offline Banner */}
      {isOffline && (
        <div className="bg-[#1B1F25] border-b border-[#C9A449]/30 px-4 py-2.5">
          <div className="max-w-7xl mx-auto flex items-center gap-2.5 text-xs text-[#E5C675]">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>{t.common.offlineNotice}</span>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 md:pt-8 pb-24 md:pb-12">
        {activeTab === 'home' && (
          <HomeView
            lang={lang}
            dailyWisdom={dailyWisdom}
            situations={situations}
            loading={loadingInitial}
            preferences={preferences}
            isBookmarked={isBookmarked}
            onToggleBookmark={handleToggleBookmark}
            onNavigate={handleNavigate}
            onOpenScripture={handleOpenScripture}
            onOpenOneHumanityTopic={handleOpenOneHumanityTopic}
            onAskQuestion={handleAskQuestion}
          />
        )}

        {activeTab === 'scriptures' && (
          <ScripturesView
            lang={lang}
            activeScripture={activeScripture}
            onChangeScripture={setActiveScripture}
            preferences={preferences}
            onUpdatePreferences={setPreferences}
            isBookmarked={isBookmarked}
            onToggleBookmark={handleToggleBookmark}
          />
        )}

        {activeTab === 'one-humanity' && (
          <OneHumanityView
            lang={lang}
            topics={oneHumanityTopics}
            selectedTopicId={selectedHumanityTopicId}
            onSelectTopic={setSelectedHumanityTopicId}
            loading={loadingInitial}
            preferences={preferences}
            isBookmarked={isBookmarked}
            onToggleBookmark={handleToggleBookmark}
            onAskTopic={handleAskQuestion}
          />
        )}

        {activeTab === 'ask-relief' && (
          <AskReliefView
            lang={lang}
            pendingQuestion={pendingAskQuestion}
            onClearPendingQuestion={() => setPendingAskQuestion(null)}
            preferences={preferences}
            isBookmarked={isBookmarked}
            onToggleBookmark={handleToggleBookmark}
          />
        )}

        {activeTab === 'bookmarks' && (
          <BookmarksView
            lang={lang}
            bookmarks={bookmarks}
            preferences={preferences}
            onToggleBookmark={handleToggleBookmark}
            onUpdateNote={handleUpdateBookmarkNote}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            lang={lang}
            onChangeLang={setLang}
            preferences={preferences}
            onUpdatePreferences={setPreferences}
            onReplayOnboarding={() => setShowOnboarding(true)}
          />
        )}
      </main>

      {/* Quiet Editorial Footer (Desktop) */}
      <footer className="hidden md:block border-t border-[#F3F0E8]/8 py-6">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 flex flex-wrap items-center justify-between gap-4 text-xs text-[#7D7970]">
          <div className="flex items-center gap-2">
            <Compass className="w-3.5 h-3.5 text-[#C9A449]" />
            <span>{t.tagline}</span>
          </div>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => handleNavigate('profile')}
              className="hover:text-[#F3F0E8] transition-colors cursor-pointer"
            >
              {t.profile.attributions}
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('profile')}
              className="hover:text-[#F3F0E8] transition-colors cursor-pointer"
            >
              {t.profile.privacyPolicy}
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('profile')}
              className="hover:text-[#F3F0E8] transition-colors cursor-pointer"
            >
              {t.profile.androidExport}
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0D0E11]/95 backdrop-blur-md border-t border-[#F3F0E8]/10 pb-safe"
      >
        <div className="grid grid-cols-5 items-center h-16">
          {mobileTabs.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className={`min-h-[48px] flex flex-col items-center justify-center gap-1 px-1 transition-colors cursor-pointer ${
                  active ? 'text-[#C9A449]' : 'text-[#A6A197]'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium tracking-tight truncate max-w-full">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* First-Launch / Replayable Onboarding */}
      <OnboardingModal
        isOpen={showOnboarding}
        lang={lang}
        onChangeLang={setLang}
        onComplete={handleCompleteOnboarding}
      />
    </div>
  );
}
