import React, { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  RotateCcw,
  Send,
  ShieldAlert,
} from 'lucide-react';
import {
  AppLang,
  AskReliefResponse,
  ChatTurn,
  HydratedVerse,
  ReadingPreferences,
} from '../types';
import { UI_COPY } from '../i18n/translations';
import { VerseCard } from './VerseCard';

interface AskReliefViewProps {
  lang: AppLang;
  pendingQuestion: string | null;
  onClearPendingQuestion: () => void;
  preferences: ReadingPreferences;
  isBookmarked: (id: string) => boolean;
  onToggleBookmark: (verse: HydratedVerse) => void;
}

export const AskReliefView: React.FC<AskReliefViewProps> = ({
  lang,
  pendingQuestion,
  onClearPendingQuestion,
  preferences,
  isBookmarked,
  onToggleBookmark,
}) => {
  const t = UI_COPY[lang];
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [input, setInput] = useState('');
  const [isAsking, setIsAsking] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  const submitQuestion = async (questionText: string) => {
    const clean = questionText.trim();
    if (!clean || isAsking) return;

    const turnId = `turn_${Date.now()}`;
    const newTurn: ChatTurn = {
      id: turnId,
      question: clean,
      timestamp: new Date().toISOString(),
    };

    const historyPayload = turns.flatMap((item) => {
      const entries: Array<{ role: 'user' | 'assistant'; question?: string; summary?: string }> = [
        { role: 'user', question: item.question },
      ];
      if (item.response) {
        entries.push({
          role: 'assistant',
          summary: `${item.response.situationSummary} ${item.response.sharedWisdom}`,
        });
      }
      return entries;
    });

    setTurns((prev) => [...prev, newTurn]);
    setInput('');
    setIsAsking(true);

    try {
      const res = await fetch('/api/ask-relief', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: clean,
          language: lang,
          history: historyPayload,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Unable to generate wisdom reflection.');
      }
      setTurns((prev) =>
        prev.map((item) =>
          item.id === turnId
            ? { ...item, response: data as AskReliefResponse }
            : item
        )
      );
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Network issue while retrieving reflection.';
      setTurns((prev) =>
        prev.map((item) =>
          item.id === turnId ? { ...item, error: msg } : item
        )
      );
    } finally {
      setIsAsking(false);
    }
  };

  useEffect(() => {
    if (pendingQuestion) {
      submitQuestion(pendingQuestion);
      onClearPendingQuestion();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingQuestion]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns.length, isAsking]);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitQuestion(input);
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Header */}
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-[#F3F0E8]/8">
        <div className="space-y-2 max-w-3xl">
          <h1 className="font-display text-3xl sm:text-4xl font-medium text-[#F3F0E8]">
            {t.ask.title}
          </h1>
          <p className="text-sm sm:text-base text-[#A6A197] leading-relaxed">
            {t.ask.subtitle}
          </p>
        </div>

        {turns.length > 0 && (
          <button
            type="button"
            onClick={() => setTurns([])}
            className="min-h-[44px] px-4 py-2 rounded-xl border border-[#F3F0E8]/15 text-xs font-medium text-[#F3F0E8] hover:border-[#C9A449] hover:text-[#C9A449] transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer self-start sm:self-auto"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.ask.newConversation}</span>
          </button>
        )}
      </section>

      {/* Starter Prompts when empty */}
      {turns.length === 0 && (
        <section className="space-y-4">
          <p className="text-xs uppercase tracking-widest text-[#C9A449]">
            {t.ask.starterLabel}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {t.ask.starters.map((starter) => (
              <button
                key={starter}
                type="button"
                onClick={() => submitQuestion(starter)}
                className="text-left min-h-[56px] bg-[#15181C] border border-[#F3F0E8]/10 hover:border-[#C9A449]/45 rounded-2xl px-5 py-3.5 text-sm text-[#F3F0E8] transition-colors cursor-pointer"
              >
                {starter}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Conversation Turns */}
      <section className="space-y-10">
        {turns.map((turn) => (
          <div key={turn.id} className="space-y-6">
            {/* User Question */}
            <div className="bg-[#1B1F25] border border-[#C9A449]/30 rounded-2xl p-5 sm:p-6">
              <p className="text-xs uppercase tracking-widest text-[#C9A449] mb-2">
                {lang === 'hi' ? 'आपका प्रश्न' : 'Your Question'}
              </p>
              <p className="font-display text-2xl sm:text-3xl text-[#F3F0E8] leading-snug">
                {turn.question}
              </p>
            </div>

            {/* Loading state for current unanswered turn */}
            {!turn.response && !turn.error && (
              <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 text-sm text-[#A6A197]">
                {t.ask.thinking}
              </div>
            )}

            {/* Error state */}
            {turn.error && (
              <div className="bg-[#15181C] border border-amber-500/40 rounded-2xl p-6 space-y-3">
                <div className="flex items-start gap-3 text-amber-300">
                  <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p className="text-sm leading-relaxed">{turn.error}</p>
                </div>
                <button
                  type="button"
                  onClick={() => submitQuestion(turn.question)}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-[#C9A449] text-[#0D0E11] text-xs font-semibold cursor-pointer"
                >
                  {t.common.retry}
                </button>
              </div>
            )}

            {/* Structured Grounded Response */}
            {turn.response && (
              <div className="space-y-6">
                {/* Situation Summary */}
                <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 sm:p-6 space-y-2">
                  <div className="flex items-center justify-between gap-2 text-xs text-[#A6A197]">
                    <span className="uppercase tracking-widest text-[#C9A449]">
                      {t.ask.situationRead}
                    </span>
                    <span>{t.common.aiReflectionTag}</span>
                  </div>
                  <p className="text-sm sm:text-base text-[#F3F0E8]/95 leading-relaxed">
                    {turn.response.situationSummary}
                  </p>
                </div>

                {/* Professional Guidance Warning if triggered */}
                {turn.response.professionalGuidanceNote && (
                  <div className="bg-[#1E1A16] border border-[#C9A449]/50 rounded-2xl p-5 sm:p-6 flex items-start gap-3.5">
                    <ShieldAlert className="w-5 h-5 text-[#C9A449] shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                        {t.ask.professionalHelp}
                      </h3>
                      <p className="text-sm text-[#F3F0E8] leading-relaxed">
                        {turn.response.professionalGuidanceNote}
                      </p>
                    </div>
                  </div>
                )}

                {/* Retrieved Verified Passages (Strict Archive Separation) */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  <div className="space-y-3">
                    <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                      {t.ask.verifiedQuran}
                    </h3>
                    {turn.response.quranVerses.length > 0 ? (
                      <div className="space-y-4">
                        {turn.response.quranVerses.map((v) => (
                          <VerseCard
                            key={v.id}
                            verse={v}
                            lang={lang}
                            preferences={preferences}
                            isBookmarked={isBookmarked(v.id)}
                            onToggleBookmark={onToggleBookmark}
                            compact
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 text-sm text-[#A6A197]">
                        {t.ask.noDirectPassage}
                      </div>
                    )}
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                      {t.ask.verifiedGita}
                    </h3>
                    {turn.response.gitaVerses.length > 0 ? (
                      <div className="space-y-4">
                        {turn.response.gitaVerses.map((v) => (
                          <VerseCard
                            key={v.id}
                            verse={v}
                            lang={lang}
                            preferences={preferences}
                            isBookmarked={isBookmarked(v.id)}
                            onToggleBookmark={onToggleBookmark}
                            compact
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 text-sm text-[#A6A197]">
                        {t.ask.noDirectPassage}
                      </div>
                    )}
                  </div>
                </div>

                {/* Independent Explanations */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 sm:p-6 space-y-2">
                    <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                      {t.ask.quranPerspective}
                    </h3>
                    <p className="text-sm sm:text-base text-[#F3F0E8]/90 leading-relaxed">
                      {turn.response.quranExplanation}
                    </p>
                  </div>

                  <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 sm:p-6 space-y-2">
                    <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                      {t.ask.gitaPerspective}
                    </h3>
                    <p className="text-sm sm:text-base text-[#F3F0E8]/90 leading-relaxed">
                      {turn.response.gitaExplanation}
                    </p>
                  </div>
                </div>

                {/* Shared Wisdom & Differences */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  <div className="bg-[#15181C] border border-[#C9A449]/25 rounded-2xl p-5 sm:p-6 space-y-2">
                    <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                      {t.ask.sharedWisdom}
                    </h3>
                    <p className="text-sm sm:text-base text-[#F3F0E8] leading-relaxed">
                      {turn.response.sharedWisdom}
                    </p>
                  </div>

                  <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 sm:p-6 space-y-2">
                    <h3 className="text-xs uppercase tracking-widest text-[#A6A197]">
                      {t.ask.differences}
                    </h3>
                    <p className="text-sm sm:text-base text-[#F3F0E8]/90 leading-relaxed">
                      {turn.response.philosophicalDifferences}
                    </p>
                  </div>
                </div>

                {/* Practical Steps */}
                <div className="bg-[#1B1F25] border border-[#F3F0E8]/10 rounded-2xl p-5 sm:p-6 space-y-3">
                  <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                    {t.ask.practicalSteps}
                  </h3>
                  <ul className="space-y-2.5">
                    {turn.response.practicalSteps.map((step, i) => (
                      <li
                        key={i}
                        className="text-sm sm:text-base text-[#F3F0E8] leading-relaxed flex items-start gap-3"
                      >
                        <span className="font-mono-num text-xs text-[#C9A449] mt-1">
                          0{i + 1}.
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                  <p className="pt-3 border-t border-[#F3F0E8]/8 text-xs text-[#A6A197]">
                    {turn.response.disclaimer}
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </section>

      {/* Ask Input Form */}
      <form
        onSubmit={handleFormSubmit}
        className="bg-[#15181C] border border-[#F3F0E8]/15 rounded-2xl p-3 sm:p-4 space-y-2 sticky bottom-20 md:bottom-4 z-20 shadow-2xl"
      >
        {turns.length > 0 && (
          <p className="text-[11px] text-[#A6A197] px-1">
            {t.ask.followUpHint}
          </p>
        )}
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
          <textarea
            rows={2}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                submitQuestion(input);
              }
            }}
            placeholder={t.ask.placeholder}
            className="flex-1 bg-[#0D0E11] border border-[#F3F0E8]/10 rounded-xl px-4 py-2.5 text-sm text-[#F3F0E8] placeholder:text-[#7D7970] focus:outline-none focus:border-[#C9A449] resize-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || isAsking}
            className="min-h-[48px] px-6 py-3 rounded-xl bg-[#C9A449] text-[#0D0E11] text-sm font-semibold inline-flex items-center justify-center gap-2 hover:bg-[#D8B55B] disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>{isAsking ? '...' : t.ask.send}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
