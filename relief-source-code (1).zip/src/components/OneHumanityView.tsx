import React, { useState } from 'react';
import { ArrowRight, Scale } from 'lucide-react';
import {
  AppLang,
  HydratedVerse,
  OneHumanityTopic,
  ReadingPreferences,
} from '../types';
import { UI_COPY } from '../i18n/translations';
import { VerseCard } from './VerseCard';

interface OneHumanityViewProps {
  lang: AppLang;
  topics: OneHumanityTopic[];
  selectedTopicId: string;
  onSelectTopic: (id: string) => void;
  loading: boolean;
  preferences: ReadingPreferences;
  isBookmarked: (id: string) => boolean;
  onToggleBookmark: (verse: HydratedVerse) => void;
  onAskTopic: (question: string) => void;
}

export const OneHumanityView: React.FC<OneHumanityViewProps> = ({
  lang,
  topics,
  selectedTopicId,
  onSelectTopic,
  loading,
  preferences,
  isBookmarked,
  onToggleBookmark,
  onAskTopic,
}) => {
  const t = UI_COPY[lang];
  const [imgFailed, setImgFailed] = useState(false);

  const activeTopic =
    topics.find((item) => item.id === selectedTopicId) || topics[0] || null;

  return (
    <div className="space-y-8 pb-10">
      {/* Header Banner */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch bg-[#15181C] border border-[#F3F0E8]/10 rounded-3xl overflow-hidden">
        <div className="lg:col-span-8 p-6 sm:p-8 flex flex-col justify-center space-y-3">
          <p className="text-xs uppercase tracking-widest text-[#C9A449]">
            {t.tagline}
          </p>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-medium text-[#F3F0E8] text-balance">
            {t.oneHumanity.title}
          </h1>
          <p className="text-sm sm:text-base text-[#A6A197] leading-relaxed max-w-2xl">
            {t.oneHumanity.subtitle}
          </p>
        </div>

        <div className="lg:col-span-4 relative min-h-[180px] bg-[#0D0E11]">
          {!imgFailed ? (
            <img
              src="/src/assets/images/unity_light_prism_1795635212936.jpg"
              alt="Two warm amber light beams meeting calmly in a dark stone chamber"
              referrerPolicy="no-referrer"
              onError={() => setImgFailed(true)}
              className="w-full h-full object-cover lg:absolute lg:inset-0"
            />
          ) : (
            <div className="w-full h-full min-h-[180px] flex items-center justify-center bg-gradient-to-br from-[#1C1F26] to-[#0D0E11]">
              <Scale className="w-8 h-8 text-[#C9A449]" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-r from-[#15181C]/60 via-transparent to-transparent pointer-events-none hidden lg:block" />
        </div>
      </section>

      {/* 15 Values Topic Selector */}
      <section className="flex flex-wrap gap-2">
        {topics.map((topic, index) => {
          const active = activeTopic?.id === topic.id;
          return (
            <button
              key={topic.id}
              type="button"
              onClick={() => onSelectTopic(topic.id)}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer ${
                active
                  ? 'bg-[#C9A449] text-[#0D0E11]'
                  : 'bg-[#15181C] text-[#A6A197] border border-[#F3F0E8]/10 hover:text-[#F3F0E8] hover:border-[#F3F0E8]/25'
              }`}
            >
              <span className="font-mono-num text-[11px] opacity-75">
                {String(index + 1).padStart(2, '0')}
              </span>
              <span>{topic.title[lang]}</span>
            </button>
          );
        })}
      </section>

      {/* Comparative Study */}
      {loading && !activeTopic ? (
        <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-8 text-sm text-[#A6A197]">
          {t.common.loading}
        </div>
      ) : activeTopic ? (
        <section className="space-y-6">
          <div className="flex flex-wrap items-end justify-between gap-4 pb-4 border-b border-[#F3F0E8]/8">
            <div>
              <h2 className="font-display text-3xl md:text-4xl font-medium text-[#F3F0E8]">
                {activeTopic.title[lang]}
              </h2>
              <p className="text-sm text-[#A6A197] mt-1">
                {activeTopic.subtitle[lang]}
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                onAskTopic(
                  lang === 'hi'
                    ? `मैं अपने दैनिक जीवन में "${activeTopic.title.hi}" को कैसे अभ्यास में लाऊँ?`
                    : `How can I practice ${activeTopic.title.en.toLowerCase()} in difficult everyday moments?`
                )
              }
              className="min-h-[44px] px-4 py-2 rounded-xl border border-[#C9A449]/40 text-xs font-medium text-[#C9A449] hover:bg-[#C9A449]/10 transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{t.home.askAboutSituation}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 1 & 2. Verified Original Verses */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="space-y-3">
              <p className="text-xs uppercase tracking-widest text-[#C9A449]">
                {t.oneHumanity.quranTeaching}
              </p>
              {activeTopic.quranVerse && (
                <VerseCard
                  verse={activeTopic.quranVerse}
                  lang={lang}
                  preferences={preferences}
                  isBookmarked={isBookmarked(activeTopic.quranVerse.id)}
                  onToggleBookmark={onToggleBookmark}
                />
              )}
            </div>

            <div className="space-y-3">
              <p className="text-xs uppercase tracking-widest text-[#C9A449]">
                {t.oneHumanity.gitaTeaching}
              </p>
              {activeTopic.gitaVerse && (
                <VerseCard
                  verse={activeTopic.gitaVerse}
                  lang={lang}
                  preferences={preferences}
                  isBookmarked={isBookmarked(activeTopic.gitaVerse.id)}
                  onToggleBookmark={onToggleBookmark}
                />
              )}
            </div>
          </div>

          {/* 3. Independent Explanations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-2.5">
              <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                {t.oneHumanity.quranContext}
              </h3>
              <p className="text-sm md:text-base text-[#F3F0E8]/90 leading-relaxed">
                {activeTopic.quranExplanation[lang]}
              </p>
            </div>

            <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-2.5">
              <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                {t.oneHumanity.gitaContext}
              </h3>
              <p className="text-sm md:text-base text-[#F3F0E8]/90 leading-relaxed">
                {activeTopic.gitaExplanation[lang]}
              </p>
            </div>
          </div>

          {/* 4 & 5. Shared Principle & Honest Differences */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="bg-[#15181C] border border-[#C9A449]/25 rounded-2xl p-6 space-y-2.5">
              <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                {t.oneHumanity.sharedPrinciple}
              </h3>
              <p className="text-sm md:text-base text-[#F3F0E8] leading-relaxed">
                {activeTopic.sharedPrinciple[lang]}
              </p>
            </div>

            <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-2.5">
              <h3 className="text-xs uppercase tracking-widest text-[#A6A197]">
                {t.oneHumanity.differences}
              </h3>
              <p className="text-sm md:text-base text-[#F3F0E8]/90 leading-relaxed">
                {activeTopic.differences[lang]}
              </p>
            </div>
          </div>

          {/* 6. Practical Everyday Application */}
          <div className="bg-[#1B1F25] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-2.5">
            <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
              {t.oneHumanity.practicalApp}
            </h3>
            <p className="text-sm md:text-base text-[#F3F0E8] leading-relaxed">
              {activeTopic.practicalApplication[lang]}
            </p>
          </div>
        </section>
      ) : null}
    </div>
  );
};
