import React, { useState } from 'react';
import {
  CheckCircle2,
  ChevronRight,
  Download,
  FileText,
  Info,
  Shield,
  Smartphone,
  X,
} from 'lucide-react';
import { AppLang, ReadingPreferences } from '../types';
import { UI_COPY } from '../i18n/translations';

interface ProfileViewProps {
  lang: AppLang;
  onChangeLang: (lang: AppLang) => void;
  preferences: ReadingPreferences;
  onUpdatePreferences: (prefs: ReadingPreferences) => void;
  onReplayOnboarding: () => void;
}

type DocModalType = 'privacy' | 'terms' | 'attribution' | 'android' | null;

export const ProfileView: React.FC<ProfileViewProps> = ({
  lang,
  onChangeLang,
  preferences,
  onUpdatePreferences,
  onReplayOnboarding,
}) => {
  const t = UI_COPY[lang];
  const [openModal, setOpenModal] = useState<DocModalType>(null);
  const [feedbackCat, setFeedbackCat] = useState('general');
  const [feedbackEmail, setFeedbackEmail] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState('');
  const [feedbackState, setFeedbackState] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<'idle' | 'done' | 'error'>('idle');

  const handleDownloadZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    setDownloadStatus('idle');
    try {
      const res = await fetch('/api/export-source');
      if (!res.ok) throw new Error('Export failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'relief-source-code.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setDownloadStatus('done');
    } catch {
      setDownloadStatus('error');
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackMsg.trim()) return;
    setFeedbackState('sending');
    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category: feedbackCat,
          email: feedbackEmail,
          message: feedbackMsg,
        }),
      });
      if (!res.ok) throw new Error('Failed');
      setFeedbackState('sent');
      setFeedbackMsg('');
    } catch {
      setFeedbackState('error');
    }
  };

  return (
    <div className="space-y-8 pb-10">
      <section className="pb-5 border-b border-[#F3F0E8]/8">
        <h1 className="font-display text-3xl sm:text-4xl font-medium text-[#F3F0E8]">
          {t.profile.title}
        </h1>
        <p className="text-sm text-[#A6A197] mt-1">{t.profile.subtitle}</p>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Language & Reading Preferences */}
        <div className="space-y-6">
          <section className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="text-base font-semibold text-[#F3F0E8]">
                {t.profile.languageSection}
              </h2>
              <p className="text-xs text-[#A6A197] mt-1">{t.profile.languageDesc}</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => onChangeLang('en')}
                className={`min-h-[48px] px-4 py-2.5 rounded-xl text-sm font-medium border transition-colors cursor-pointer ${
                  lang === 'en'
                    ? 'bg-[#C9A449] text-[#0D0E11] border-[#C9A449]'
                    : 'bg-[#0D0E11] text-[#F3F0E8] border-[#F3F0E8]/10 hover:border-[#C9A449]/40'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => onChangeLang('hi')}
                className={`min-h-[48px] px-4 py-2.5 rounded-xl text-sm font-medium border transition-colors cursor-pointer ${
                  lang === 'hi'
                    ? 'bg-[#C9A449] text-[#0D0E11] border-[#C9A449]'
                    : 'bg-[#0D0E11] text-[#F3F0E8] border-[#F3F0E8]/10 hover:border-[#C9A449]/40'
                }`}
              >
                हिन्दी (Hindi)
              </button>
            </div>
          </section>

          <section className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-semibold text-[#F3F0E8]">
              {t.profile.readingSection}
            </h2>

            <div className="space-y-3">
              {[
                {
                  key: 'showOriginalScript' as const,
                  label: t.scriptures.showOriginal,
                  sub: lang === 'hi' ? 'मूल अरबी और संस्कृत पाठ दिखाएँ' : 'Display original Arabic and Sanskrit script',
                },
                {
                  key: 'showTransliteration' as const,
                  label: t.scriptures.showTranslit,
                  sub: lang === 'hi' ? 'गीता श्लोकों का रोमन उच्चारण दिखाएँ' : 'Display IAST transliteration for Gita verses',
                },
                {
                  key: 'showDualTranslation' as const,
                  label: t.scriptures.showDual,
                  sub: lang === 'hi' ? 'हिंदी और अंग्रेज़ी दोनों अनुवाद साथ देखें' : 'Show both English and Hindi translations together',
                },
              ].map((item) => (
                <label
                  key={item.key}
                  className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#0D0E11] border border-[#F3F0E8]/8 cursor-pointer min-h-[56px]"
                >
                  <div>
                    <p className="text-sm font-medium text-[#F3F0E8]">{item.label}</p>
                    <p className="text-xs text-[#A6A197]">{item.sub}</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={preferences[item.key]}
                    onChange={(e) =>
                      onUpdatePreferences({
                        ...preferences,
                        [item.key]: e.target.checked,
                      })
                    }
                    className="w-5 h-5 accent-[#C9A449] rounded cursor-pointer"
                  />
                </label>
              ))}
            </div>
          </section>

          {/* Commercial Readiness */}
          <section className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-3">
            <p className="text-xs uppercase tracking-widest text-[#C9A449]">
              {t.profile.editionSection}
            </p>
            <h2 className="font-display text-2xl text-[#F3F0E8]">
              {t.profile.editionTitle}
            </h2>
            <p className="text-xs font-medium text-[#E5C675]">
              {t.profile.editionStatus}
            </p>
            <p className="text-xs text-[#A6A197] leading-relaxed">
              {t.profile.editionNote}
            </p>
            <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-[#F3F0E8]/8">
              <span className="text-xs text-[#A6A197]">
                {t.profile.versionLabel}: <span className="font-mono-num text-[#F3F0E8]">1.0.0 (Build 1)</span>
              </span>
              <button
                type="button"
                onClick={onReplayOnboarding}
                className="min-h-[40px] px-3.5 py-1.5 rounded-xl border border-[#F3F0E8]/15 text-xs font-medium text-[#F3F0E8] hover:border-[#C9A449] cursor-pointer"
              >
                {t.profile.replayOnboarding}
              </button>
            </div>
          </section>
        </div>

        {/* Policies, Android Export & Feedback */}
        <div className="space-y-6">
          <section className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-3">
            <h2 className="text-base font-semibold text-[#F3F0E8] mb-2">
              {t.profile.trustSection}
            </h2>

            {[
              { id: 'privacy' as const, label: t.profile.privacyPolicy, icon: Shield },
              { id: 'terms' as const, label: t.profile.termsOfUse, icon: FileText },
              { id: 'attribution' as const, label: t.profile.attributions, icon: Info },
              { id: 'android' as const, label: t.profile.androidExport, icon: Smartphone },
            ].map((row) => {
              const Icon = row.icon;
              return (
                <button
                  key={row.id}
                  type="button"
                  onClick={() => setOpenModal(row.id)}
                  className="w-full min-h-[52px] px-4 py-3 rounded-xl bg-[#0D0E11] border border-[#F3F0E8]/8 hover:border-[#C9A449]/40 flex items-center justify-between gap-3 text-left transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-3 text-sm font-medium text-[#F3F0E8]">
                    <Icon className="w-4 h-4 text-[#C9A449] shrink-0" />
                    <span>{row.label}</span>
                  </span>
                  <ChevronRight className="w-4 h-4 text-[#A6A197] shrink-0" />
                </button>
              );
            })}

            <div className="pt-2 border-t border-[#F3F0E8]/8 space-y-2">
              <button
                type="button"
                onClick={handleDownloadZip}
                disabled={downloadingZip}
                className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-[#C9A449] text-[#0D0E11] text-sm font-semibold hover:bg-[#D8B55B] disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4 shrink-0" />
                <span>{downloadingZip ? t.profile.downloadingZip : t.profile.downloadZip}</span>
              </button>
              {downloadStatus === 'done' && (
                <p className="text-xs text-[#C9A449] text-center">{t.profile.downloadReady}</p>
              )}
              {downloadStatus === 'error' && (
                <p className="text-xs text-amber-300 text-center">{t.common.offlineNotice}</p>
              )}
            </div>
          </section>

          {/* Feedback Form */}
          <section className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-semibold text-[#F3F0E8]">
              {t.profile.feedbackSection}
            </h2>

            <form onSubmit={handleFeedbackSubmit} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <select
                  value={feedbackCat}
                  onChange={(e) => setFeedbackCat(e.target.value)}
                  className="min-h-[44px] bg-[#0D0E11] border border-[#F3F0E8]/12 rounded-xl px-3.5 py-2 text-sm text-[#F3F0E8] focus:outline-none focus:border-[#C9A449]"
                >
                  <option value="general">{lang === 'hi' ? 'सामान्य सुझाव' : 'General Feedback'}</option>
                  <option value="translation">{lang === 'hi' ? 'अनुवाद टिप्पणी' : 'Translation Note'}</option>
                  <option value="support">{lang === 'hi' ? 'तकनीकी सहायता' : 'Technical Support'}</option>
                </select>
                <input
                  type="email"
                  value={feedbackEmail}
                  onChange={(e) => setFeedbackEmail(e.target.value)}
                  placeholder={t.profile.feedbackEmail}
                  className="min-h-[44px] bg-[#0D0E11] border border-[#F3F0E8]/12 rounded-xl px-3.5 py-2 text-sm text-[#F3F0E8] placeholder:text-[#7D7970] focus:outline-none focus:border-[#C9A449]"
                />
              </div>

              <textarea
                rows={3}
                value={feedbackMsg}
                onChange={(e) => setFeedbackMsg(e.target.value)}
                placeholder={t.profile.feedbackMessage}
                className="w-full bg-[#0D0E11] border border-[#F3F0E8]/12 rounded-xl px-3.5 py-2.5 text-sm text-[#F3F0E8] placeholder:text-[#7D7970] focus:outline-none focus:border-[#C9A449]"
              />

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  type="submit"
                  disabled={!feedbackMsg.trim() || feedbackState === 'sending'}
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-[#C9A449] text-[#0D0E11] text-sm font-semibold hover:bg-[#D8B55B] disabled:opacity-40 cursor-pointer"
                >
                  {feedbackState === 'sending' ? '...' : t.common.submit}
                </button>

                {feedbackState === 'sent' && (
                  <span className="text-xs text-[#C9A449] inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    {t.profile.feedbackSuccess}
                  </span>
                )}
                {feedbackState === 'error' && (
                  <span className="text-xs text-amber-300">
                    {t.common.offlineNotice}
                  </span>
                )}
              </div>
            </form>
          </section>
        </div>
      </div>

      {/* Document / Guide Modal */}
      {openModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto bg-[#15181C] border border-[#F3F0E8]/12 rounded-3xl p-6 sm:p-8 space-y-5">
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-[#F3F0E8]/8">
              <h3 className="font-display text-2xl sm:text-3xl text-[#F3F0E8]">
                {openModal === 'privacy' && t.profile.privacyPolicy}
                {openModal === 'terms' && t.profile.termsOfUse}
                {openModal === 'attribution' && t.profile.attributions}
                {openModal === 'android' && t.profile.androidExport}
              </h3>
              <button
                type="button"
                onClick={() => setOpenModal(null)}
                aria-label={t.common.close}
                className="min-h-[44px] min-w-[44px] rounded-xl border border-[#F3F0E8]/12 flex items-center justify-center text-[#A6A197] hover:text-[#F3F0E8] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {openModal === 'privacy' && (
              <div className="space-y-4 text-sm text-[#A6A197] leading-relaxed">
                <p>
                  <strong className="text-[#F3F0E8]">Local-First Privacy:</strong> Bookmarks, personal reflection notes, language selection, and reading display preferences are stored locally on your device.
                </p>
                <p>
                  <strong className="text-[#F3F0E8]">Ask RELIEF Queries:</strong> Questions submitted in Ask RELIEF are sent securely to the RELIEF server API solely to retrieve verified scripture passages and generate educational reflections via Gemini. No personal user profiles or advertising trackers are sold or shared.
                </p>
                <p>
                  <strong className="text-[#F3F0E8]">Feedback Submissions:</strong> Optional email addresses provided in the support form are used strictly to respond to translation notes or bug reports.
                </p>
              </div>
            )}

            {openModal === 'terms' && (
              <div className="space-y-4 text-sm text-[#A6A197] leading-relaxed">
                <p>
                  <strong className="text-[#F3F0E8]">Educational & Reflective Purpose:</strong> RELIEF is an educational wisdom platform. AI-assisted reflections are not religious decrees, fatwas, or spiritual authority rulings.
                </p>
                <p>
                  <strong className="text-[#F3F0E8]">Neutrality Charter:</strong> RELIEF respects The Holy Quran, The Bhagavad Gita, people of all faiths, and people of no religious affiliation equally. Content must never be used to promote hostility, supremacy, or harassment.
                </p>
                <p>
                  <strong className="text-[#F3F0E8]">Professional Limits:</strong> Scripture reflection is not a substitute for licensed medical, psychiatric, legal, financial, or emergency intervention.
                </p>
              </div>
            )}

            {openModal === 'attribution' && (
              <div className="space-y-4 text-sm text-[#A6A197] leading-relaxed">
                <div>
                  <h4 className="text-[#F3F0E8] font-semibold mb-1">The Holy Quran (114 Surahs · 6,236 Ayahs)</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Arabic Text: Tanzil Project (Quran Uthmani) via AlQuran Cloud</li>
                    <li>English Translation: Saheeh International via AlQuran Cloud</li>
                    <li>Hindi Translation: Suhel Farooq Khan & Saifur Rahman Nadwi via AlQuran Cloud</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-[#F3F0E8] font-semibold mb-1">The Bhagavad Gita (18 Chapters · 700 Shlokas)</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Sanskrit & IAST Transliteration: Vedic Scriptures Open Archive</li>
                    <li>English Translation: Swami Sivananda via Vedic Scriptures Open Archive</li>
                    <li>Hindi Translation: Swami Tejomayananda via Vedic Scriptures Open Archive</li>
                  </ul>
                </div>
              </div>
            )}

            {openModal === 'android' && (
              <div className="space-y-4 text-xs sm:text-sm text-[#A6A197] leading-relaxed">
                <div>
                  <h4 className="text-[#F3F0E8] font-semibold mb-1">1. Export Source Code as ZIP</h4>
                  <p className="mb-3">Download the complete source archive (including the React frontend, Express backend, verified Quran &amp; Gita datasets, and Capacitor Android project) directly:</p>
                  <button
                    type="button"
                    onClick={handleDownloadZip}
                    disabled={downloadingZip}
                    className="min-h-[44px] px-5 py-2 rounded-xl bg-[#C9A449] text-[#0D0E11] text-xs sm:text-sm font-semibold hover:bg-[#D8B55B] disabled:opacity-50 inline-flex items-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{downloadingZip ? t.profile.downloadingZip : t.profile.downloadZip}</span>
                  </button>
                  <pre className="mt-3 p-3 rounded-xl bg-[#0D0E11] border border-[#F3F0E8]/10 text-[#E5C675] overflow-x-auto font-mono-num">
                    zip -r relief-source.zip . -x "node_modules/*" "dist/*" "android/app/build/*"
                  </pre>
                </div>
                <div>
                  <h4 className="text-[#F3F0E8] font-semibold mb-1">2. Build Web Bundle & Sync Capacitor Android</h4>
                  <pre className="mt-2 p-3 rounded-xl bg-[#0D0E11] border border-[#F3F0E8]/10 text-[#E5C675] overflow-x-auto font-mono-num">
{`npm install
npm run build
npx cap add android   # first time only
npx cap sync android`}
                  </pre>
                </div>
                <div>
                  <h4 className="text-[#F3F0E8] font-semibold mb-1">3. Test APK & Signed Release AAB</h4>
                  <p>Ensure your hosted Express API URL is configured for mobile network calls, then run Gradle inside <code className="text-[#F3F0E8]">android/</code>:</p>
                  <pre className="mt-2 p-3 rounded-xl bg-[#0D0E11] border border-[#F3F0E8]/10 text-[#E5C675] overflow-x-auto font-mono-num">
{`cd android
./gradlew assembleDebug     # Test APK -> app/build/outputs/apk/debug/
./gradlew bundleRelease     # Signed AAB -> app/build/outputs/bundle/release/`}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
