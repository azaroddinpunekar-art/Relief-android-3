import React, { useState } from 'react';
import { Bookmark, Check, Share2 } from 'lucide-react';
import { AppLang, HydratedVerse, ReadingPreferences } from '../types';
import { UI_COPY } from '../i18n/translations';

interface VerseCardProps {
  verse: HydratedVerse;
  lang: AppLang;
  preferences?: ReadingPreferences;
  isBookmarked: boolean;
  onToggleBookmark: (verse: HydratedVerse) => void;
  compact?: boolean;
}

export const VerseCard: React.FC<VerseCardProps> = ({
  verse,
  lang,
  preferences = {
    showOriginalScript: true,
    showTransliteration: true,
    showDualTranslation: true,
  },
  isBookmarked,
  onToggleBookmark,
  compact = false,
}) => {
  const t = UI_COPY[lang];
  const [copied, setCopied] = useState(false);

  const primaryTranslation = lang === 'hi' ? verse.hindiText : verse.englishText;
  const secondaryTranslation = lang === 'hi' ? verse.englishText : verse.hindiText;
  const chapterLabel = lang === 'hi' ? verse.chapterTitleHi : verse.chapterTitleEn;

  const handleShare = async () => {
    const shareText = `${verse.reference} (${chapterLabel})\n\n${verse.originalText}\n\n${primaryTranslation}\n\n— RELIEF (${t.tagline})`;
    try {
      if (navigator.share) {
        await navigator.share({
          title: verse.reference,
          text: shareText,
        });
      } else {
        await navigator.clipboard.writeText(shareText);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      try {
        await navigator.clipboard.writeText(shareText);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch {
        // Ignore clipboard denial
      }
    }
  };

  return (
    <article className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 md:p-6 transition-colors duration-200 hover:border-[#C9A449]/30">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#F3F0E8]/8">
        <div className="flex flex-wrap items-center gap-2 text-xs text-[#A6A197]">
          <span className="font-mono-num text-[#C9A449] font-medium">
            {verse.reference}
          </span>
          <span aria-hidden="true">·</span>
          <span className="truncate max-w-[260px] sm:max-w-none">{chapterLabel}</span>
          <span aria-hidden="true">·</span>
          <span>{t.common.verifiedSource}</span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => onToggleBookmark(verse)}
            aria-label={isBookmarked ? t.common.bookmarked : t.common.bookmark}
            className={`min-h-[44px] min-w-[44px] px-3 inline-flex items-center justify-center gap-1.5 rounded-xl text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              isBookmarked
                ? 'bg-[#C9A449]/15 text-[#E5C675] border border-[#C9A449]/40'
                : 'text-[#A6A197] hover:text-[#F3F0E8] hover:bg-[#1E2228]'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            <span className="hidden sm:inline">
              {isBookmarked ? t.common.bookmarked : t.common.bookmark}
            </span>
          </button>

          <button
            type="button"
            onClick={handleShare}
            aria-label={t.common.share}
            className="min-h-[44px] min-w-[44px] px-3 inline-flex items-center justify-center gap-1.5 rounded-xl text-xs font-medium text-[#A6A197] hover:text-[#F3F0E8] hover:bg-[#1E2228] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-[#C9A449]" />
                <span className="hidden sm:inline text-[#C9A449]">{t.common.copied}</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4" />
                <span className="hidden sm:inline">{t.common.share}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {preferences.showOriginalScript && (
        <div className="pt-5">
          {verse.scripture === 'quran' ? (
            <p
              lang="ar"
              className={`font-arabic text-right text-[#F3F0E8] tracking-normal ${
                compact ? 'text-xl md:text-2xl' : 'text-2xl md:text-[28px]'
              }`}
            >
              {verse.originalText}
            </p>
          ) : (
            <p
              lang="sa"
              className={`font-devanagari text-[#F3F0E8] whitespace-pre-line ${
                compact ? 'text-base md:text-lg' : 'text-lg md:text-xl'
              }`}
            >
              {verse.originalText}
            </p>
          )}
        </div>
      )}

      {preferences.showTransliteration && verse.transliteration && (
        <p className="mt-3 text-xs md:text-sm italic text-[#A6A197] whitespace-pre-line leading-relaxed">
          {verse.transliteration}
        </p>
      )}

      <div className="mt-4 space-y-3">
        <p
          className={`text-[#F3F0E8]/95 leading-relaxed ${
            lang === 'hi' ? 'font-devanagari text-[15px] md:text-base' : 'text-[15px] md:text-base'
          }`}
        >
          {primaryTranslation}
        </p>

        {preferences.showDualTranslation && secondaryTranslation && (
          <p
            className={`text-sm text-[#A6A197] leading-relaxed pt-2 border-t border-[#F3F0E8]/6 ${
              lang === 'en' ? 'font-devanagari' : ''
            }`}
          >
            {secondaryTranslation}
          </p>
        )}
      </div>

      {verse.relevanceNote && (
        <p className="mt-4 pt-3 border-t border-[#F3F0E8]/8 text-xs md:text-sm text-[#C9A449]/90 leading-relaxed">
          {verse.relevanceNote}
        </p>
      )}

      <div className="mt-4 pt-3 border-t border-[#F3F0E8]/6 text-[11px] text-[#7D7970]">
        {lang === 'hi' ? verse.attributionHi : verse.attributionEn} · {verse.attributionOriginal}
      </div>
    </article>
  );
};
