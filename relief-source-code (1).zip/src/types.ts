export type AppLang = 'en' | 'hi';

export type NavTab =
  | 'home'
  | 'scriptures'
  | 'one-humanity'
  | 'ask-relief'
  | 'bookmarks'
  | 'profile';

export interface BilingualText {
  en: string;
  hi: string;
}

export interface HydratedVerse {
  id: string;
  scripture: 'quran' | 'gita';
  chapterNumber: number;
  verseNumber: number;
  chapterTitleEn: string;
  chapterTitleHi: string;
  chapterTitleOriginal: string;
  reference: string;
  originalText: string;
  transliteration?: string;
  englishText: string;
  hindiText: string;
  attributionOriginal: string;
  attributionEn: string;
  attributionHi: string;
  relevanceNote?: string;
}

export interface QuranSurahSummary {
  number: number;
  nameArabic: string;
  englishName: string;
  englishNameTranslation: string;
  revelationType: string;
  ayahCount: number;
}

export interface QuranSurahDetail extends QuranSurahSummary {
  ayahs: Array<{
    numberInSurah: number;
    arabic: string;
    english: string;
    hindi: string;
  }>;
  attribution: {
    arabic: string;
    english: string;
    hindi: string;
  };
}

export interface GitaChapterSummary {
  number: number;
  nameSanskrit: string;
  transliteration: string;
  englishName: string;
  hindiName: string;
  summaryEn: string;
  summaryHi: string;
  verseCount: number;
}

export interface GitaChapterDetail extends GitaChapterSummary {
  verses: Array<{
    verse: number;
    sanskrit: string;
    transliteration: string;
    english: string;
    hindi: string;
  }>;
  attribution: {
    sanskrit: string;
    english: string;
    hindi: string;
  };
}

export interface OneHumanityTopic {
  id: string;
  title: BilingualText;
  subtitle: BilingualText;
  quranVerse: HydratedVerse | null;
  gitaVerse: HydratedVerse | null;
  quranExplanation: BilingualText;
  gitaExplanation: BilingualText;
  sharedPrinciple: BilingualText;
  differences: BilingualText;
  practicalApplication: BilingualText;
}

export interface SituationCategory {
  id: string;
  title: BilingualText;
  summary: BilingualText;
  quranVerses: HydratedVerse[];
  gitaVerses: HydratedVerse[];
  reflection: BilingualText;
  practicalSteps: { en: string[]; hi: string[] };
}

export interface DailyWisdom {
  date: string;
  topicId: string;
  title: BilingualText;
  subtitle: BilingualText;
  quranVerse: HydratedVerse | null;
  gitaVerse: HydratedVerse | null;
  sharedPrinciple: BilingualText;
}

export interface AskReliefResponse {
  detectedLanguage: 'en' | 'hi';
  situationSummary: string;
  quranVerses: HydratedVerse[];
  gitaVerses: HydratedVerse[];
  quranExplanation: string;
  gitaExplanation: string;
  sharedWisdom: string;
  philosophicalDifferences: string;
  practicalSteps: string[];
  professionalGuidanceNote: string;
  disclaimer: string;
}

export interface ChatTurn {
  id: string;
  question: string;
  response?: AskReliefResponse;
  error?: string;
  timestamp: string;
}

export interface BookmarkItem {
  verse: HydratedVerse;
  savedAt: string;
  note?: string;
}

export interface ReadingPreferences {
  showOriginalScript: boolean;
  showTransliteration: boolean;
  showDualTranslation: boolean;
}
